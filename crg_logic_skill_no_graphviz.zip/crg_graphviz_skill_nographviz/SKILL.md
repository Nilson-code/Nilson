---
name: crg_graphviz_logic_renderer
description: Render CRG clock/reset logic from an Excel table into concise, polished diagrams with deterministic DOT/SVG/PNG outputs. Supports Graphviz and no-Graphviz pure-Python rendering.
---

# CRG Graphviz Logic Renderer

Use this skill when the user provides an Excel workbook that describes CRG, clock tree, reset tree, or related hardware logic and asks for a readable logic diagram.

## Input contract

Preferred worksheet schema:

| Column | Required | Meaning |
|---|---:|---|
| `NAME` | yes | Unique node/signal/module name. |
| `TYPE` | yes | Logic type: `SRC`, `SINK`, `BUF`, `DIV`, `SYNC`, `CG`, `AND`, `MUX`, or `SIGNAL`. Unknown types may be rendered as `SIGNAL` unless the user requests a new style. |
| `IN1...INn` | at least one IN or OUT group | Upstream inputs. Each non-empty cell creates `input -> NAME`. |
| `OUT1...OUTn` | at least one IN or OUT group | Downstream outputs. Each non-empty cell creates `NAME -> output`. |
| `NOTE` | optional | Annotation; do not render by default unless the user asks for rich labels. |

Header names are case-insensitive. Blank rows are ignored. `NAME` must be unique for stable output.

## Parsing rules

1. Inspect the workbook and identify the header row containing `NAME`, `TYPE`, and at least one `IN*` or `OUT*` column.
2. For every row:
   - Create one primary node from `NAME`.
   - Create input edges from each `IN*` cell: `INx -> NAME`.
   - Create output edges from each `OUT*` cell: `NAME -> OUTx`.
3. Deduplicate edges.
4. Auto-create missing referenced nodes as `SIGNAL`.
5. Preserve workbook row order for deterministic node ordering.
6. Quote every DOT identifier. Never inject raw Excel text into DOT IDs.
7. Allow cycles; CRG feedback or preserve paths may be intentional. Do not delete cycles.

## Layout rules

Default to the optimized fixed-lane layout for CRG diagrams. The renderer generates deterministic node coordinates from Excel order and CRG semantics. It can render through Graphviz `neato -n2` when Graphviz is available, or through the pure-Python backend when Graphviz is not installed. Use the older clustered layout only when the user explicitly wants automatic Graphviz clustering.


### Stable CRG skeleton rule

For the standard CRG workbook family, do **not** reflow the whole graph when optional buffer rows are removed. Recognize the semantic backbone nodes (`clk_in`, `div2`, `u_crg_preserve_occ_buf`, `single_sync`, `cg1`, `cg2`, `and1`, `mux1`, `rst_sync1`, `rst_sync2`, major clock/reset sinks) and apply the canonical coordinate skeleton. Treat reset-buffer aliases (`rst_buf1`, `rst_buf2`) as position-compatible replacements for the older `clk_buf5`, `clk_buf6` reset-output buffers. Missing optional nodes such as `clk_buf1...clk_buf6`, plus renamed reset buffer aliases such as `rst_buf1` / `rst_buf2`, leave empty slots. This keeps diagrams visually comparable across Excel variants.

Optimized layout rules:

- Left-to-right flow: sources on the left, sinks on the right, clock/enable logic above reset logic.
- Preserve Excel row order as the stable tie-breaker for nodes on the same logical level.
- Treat reset synchronizers, `AND`, `MUX`, and names/outputs containing `rst` or `reset` as reset-lane nodes.
- Keep enable synchronizers such as `single_sync` in the clock/enable lane unless their own name or outputs are reset-like.
- If a `SINK` is also consumed internally, create a hidden visual tap, draw the user-facing output on the right, and draw the internal dependency as a dashed labeled branch. This avoids backward output-to-core edges without changing the logic.

Clustered fallback graph attributes:

```dot
rankdir=LR
splines=ortho
nodesep=0.38
ranksep=0.78
compound=true
newrank=true
concentrate=false
bgcolor="#FAFAFA"
```

For clustered fallback, cluster nodes into four lanes:

- `Inputs`: `TYPE=SRC`
- `Clock / Enable Path`: non-reset internal logic
- `Reset Path`: nodes or neighbors containing `rst` / `reset`, plus `AND` and `MUX`
- `Outputs`: `TYPE=SINK`

Set `rank=same` for input and output clusters to make the graph read from left to right.

Renderer CLI default: `--layout optimized --backend auto`. Use `--backend pure` for machines without Graphviz. Use `--layout clustered` for the cluster-based Graphviz view.

## Visual style

Default palette:

| TYPE | Shape | Fill | Border |
|---|---|---|---|
| `SRC` | oval | `#DBEAFE` | `#2563EB` |
| `SINK` | oval | `#DCFCE7` | `#16A34A` |
| `BUF` | box | `#F1F5F9` | `#64748B` |
| `DIV` | box | `#EDE9FE` | `#7C3AED` |
| `SYNC` | box | `#FEF3C7` | `#D97706` |
| `CG` | box | `#FFEDD5` | `#EA580C` |
| `AND` | diamond | `#FFE4E6` | `#E11D48` |
| `MUX` | box | `#CFFAFE` | `#0891B2` |
| `SIGNAL` | oval | `#FFFFFF` | `#CBD5E1` |

Edge coloring:

- Clock-related edges: blue
- Reset-related edges: red
- Gate/enable-related edges: orange
- Other edges: slate

## Output contract

Always produce:

1. `*.dot` for debugging and reproducibility.
2. `*.svg` for crisp review and documentation. SVG can be generated without Graphviz.
3. `*.png` for quick preview in chat. PNG can be generated without Graphviz when Pillow is installed.
4. A short summary: node count, edge count, input sheet name, and any validation warnings.

When the user asks for a reusable skill/package, include:

- `SKILL.md`
- `render_crg.py`
- `config/crg_style.json`
- an Excel template
- one rendered example image

## Validation checklist

Before final delivery:

- Confirm required columns were found.
- Confirm duplicate `NAME` values are not present.
- Confirm rendered files exist and are non-empty.
- Open or render the PNG once to visually inspect overall layout.
- Keep the diagram concise; do not add a legend unless it improves comprehension or the user asks for it.


## Local machines without Graphviz

If the user has no Graphviz installation, run:

```bash
python render_crg.py -i input.xlsx -o out --backend pure --formats png,svg,dot
```

The pure backend does not call `dot`, `neato`, or any Graphviz executable. It preserves the same stable CRG skeleton and deterministic fallback rules, then draws SVG directly and PNG through Pillow. It is intended for portable local use. Graphviz output remains available for users who want native DOT rendering.
