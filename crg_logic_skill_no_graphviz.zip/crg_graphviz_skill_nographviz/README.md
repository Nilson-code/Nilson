# CRG Logic Renderer

Render CRG clock/reset logic from Excel into stable logic diagrams.

This package supports two rendering backends:

- `graphviz`: uses Graphviz `neato/dot` for polished DOT rendering.
- `pure`: uses pure Python fixed-layout drawing. No Graphviz executable is required.
- `auto`: tries Graphviz first, then falls back to pure Python.

## Input Excel schema

`NAME | TYPE | IN1...INn | OUT1...OUTn | NOTE`

Every non-empty `INx` creates `INx -> NAME`; every non-empty `OUTx` creates `NAME -> OUTx`.

## Install

```bash
pip install -r requirements.txt
```

Graphviz is optional. If your machine does not have Graphviz, use `--backend pure`.

## Run without Graphviz

```bash
python render_crg.py -i examples/component_example_logic_revised.xlsx -o out --backend pure --formats png,svg,dot
```

## Run with auto fallback

```bash
python render_crg.py -i examples/component_example_logic_revised.xlsx -o out --backend auto --formats png,svg,dot
```

## Run with Graphviz explicitly

```bash
python render_crg.py -i examples/component_example_logic_revised.xlsx -o out --backend graphviz --formats png,svg
```

If Graphviz is not installed and `--backend graphviz` is used, the command will fail. Use `--backend auto` or `--backend pure` for portable local output.
