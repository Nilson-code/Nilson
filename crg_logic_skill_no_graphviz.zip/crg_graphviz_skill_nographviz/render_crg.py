#!/usr/bin/env python3
"""
Render CRG logic from an Excel edge/node table into DOT/SVG/PNG. Supports Graphviz and pure-Python rendering.

Expected Excel schema:
  NAME | TYPE | IN1 | IN2 | IN3 | IN4 | OUT1 | OUT2 | OUT3 | OUT4 | NOTE

Rule:
  Each IN cell creates an edge:   input_signal -> NAME
  Each OUT cell creates an edge:  NAME -> output_signal
  Edges are deduplicated. Nodes referenced only in IN/OUT are auto-created as SIGNAL.
"""

from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import sys
import textwrap
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Set, Tuple

try:
    from openpyxl import load_workbook
except ImportError as exc:  # pragma: no cover
    raise SystemExit("Missing dependency: openpyxl. Install with: pip install openpyxl") from exc


DEFAULT_STYLE = {
    "graph": {
        "title": "CRG Logic Map",
        "rankdir": "LR",
        "splines": "ortho",
        "bgcolor": "#FAFAFA",
        "fontname": "Helvetica",
        "nodesep": "0.38",
        "ranksep": "0.78",
        "pad": "0.28",
    },
    "clusters": {
        "src": {"label": "Inputs", "fill": "#EFF6FF", "color": "#BFDBFE"},
        "clock": {"label": "Clock / Enable Path", "fill": "#FFFFFF", "color": "#DBEAFE"},
        "reset": {"label": "Reset Path", "fill": "#FFFFFF", "color": "#FECACA"},
        "sink": {"label": "Outputs", "fill": "#F0FDF4", "color": "#BBF7D0"},
    },
    "types": {
        "SRC": {"fill": "#DBEAFE", "border": "#2563EB", "font": "#0F172A", "shape": "oval"},
        "SINK": {"fill": "#DCFCE7", "border": "#16A34A", "font": "#0F172A", "shape": "oval"},
        "BUF": {"fill": "#F1F5F9", "border": "#64748B", "font": "#0F172A", "shape": "box"},
        "DIV": {"fill": "#EDE9FE", "border": "#7C3AED", "font": "#0F172A", "shape": "box"},
        "SYNC": {"fill": "#FEF3C7", "border": "#D97706", "font": "#0F172A", "shape": "box"},
        "CG": {"fill": "#FFEDD5", "border": "#EA580C", "font": "#0F172A", "shape": "box"},
        "AND": {"fill": "#FFE4E6", "border": "#E11D48", "font": "#0F172A", "shape": "diamond"},
        "MUX": {"fill": "#CFFAFE", "border": "#0891B2", "font": "#0F172A", "shape": "box"},
        "SIGNAL": {"fill": "#FFFFFF", "border": "#CBD5E1", "font": "#334155", "shape": "oval"},
    },
    "edges": {"clock": "#2563EB", "reset": "#DC2626", "gate": "#EA580C", "default": "#64748B"},
}


@dataclass(frozen=True)
class Row:
    name: str
    type: str
    inputs: Tuple[str, ...]
    outputs: Tuple[str, ...]
    note: str = ""


def clean(value: object) -> Optional[str]:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def normalize_header(value: object) -> str:
    text = clean(value) or ""
    return re.sub(r"\s+", "", text).upper()


def find_header_row(ws, max_scan_rows: int = 20) -> Tuple[int, Dict[str, int]]:
    aliases = {
        "NAME": {"NAME", "NODE", "节点", "名称", "信号名", "模块名"},
        "TYPE": {"TYPE", "类型", "类别"},
        "NOTE": {"NOTE", "NOTES", "备注", "说明"},
    }

    for row_idx in range(1, min(ws.max_row, max_scan_rows) + 1):
        normalized = [normalize_header(ws.cell(row_idx, col).value) for col in range(1, ws.max_column + 1)]
        header_map: Dict[str, int] = {}

        for col_idx, value in enumerate(normalized, start=1):
            if value in aliases["NAME"]:
                header_map["NAME"] = col_idx
            elif value in aliases["TYPE"]:
                header_map["TYPE"] = col_idx
            elif value in aliases["NOTE"]:
                header_map["NOTE"] = col_idx
            elif re.fullmatch(r"(IN|INPUT)\d*", value):
                header_map[f"IN_{col_idx}"] = col_idx
            elif re.fullmatch(r"(OUT|OUTPUT)\d*", value):
                header_map[f"OUT_{col_idx}"] = col_idx

        has_name_type = "NAME" in header_map and "TYPE" in header_map
        has_edges = any(k.startswith("IN_") for k in header_map) or any(k.startswith("OUT_") for k in header_map)
        if has_name_type and has_edges:
            return row_idx, header_map

    raise ValueError("Cannot find header row. Required columns include NAME, TYPE, and at least one IN*/OUT* column.")


def load_rows(xlsx_path: Path, sheet_name: Optional[str] = None) -> List[Row]:
    wb = load_workbook(xlsx_path, data_only=True, read_only=False)
    if sheet_name:
        if sheet_name not in wb.sheetnames:
            raise ValueError(f"Sheet not found: {sheet_name}. Available sheets: {', '.join(wb.sheetnames)}")
        ws = wb[sheet_name]
    else:
        ws = wb[wb.sheetnames[0]]

    header_row, header_map = find_header_row(ws)
    input_cols = [v for k, v in header_map.items() if k.startswith("IN_")]
    output_cols = [v for k, v in header_map.items() if k.startswith("OUT_")]
    input_cols.sort()
    output_cols.sort()

    rows: List[Row] = []
    seen: Set[str] = set()
    for row_idx in range(header_row + 1, ws.max_row + 1):
        name = clean(ws.cell(row_idx, header_map["NAME"]).value)
        if not name:
            continue
        typ = (clean(ws.cell(row_idx, header_map["TYPE"]).value) or "SIGNAL").upper()
        note = clean(ws.cell(row_idx, header_map.get("NOTE", 0)).value) if "NOTE" in header_map else ""
        inputs = tuple(v for col in input_cols if (v := clean(ws.cell(row_idx, col).value)))
        outputs = tuple(v for col in output_cols if (v := clean(ws.cell(row_idx, col).value)))

        if name in seen:
            raise ValueError(f"Duplicate NAME at row {row_idx}: {name}. NAME must be unique for stable graph output.")
        seen.add(name)
        rows.append(Row(name=name, type=typ, inputs=inputs, outputs=outputs, note=note or ""))

    if not rows:
        raise ValueError("No logic rows found below the header.")
    return rows


def collect_graph(rows: Sequence[Row]) -> Tuple[Dict[str, str], Set[Tuple[str, str]], List[str]]:
    type_by_name: Dict[str, str] = {row.name: row.type for row in rows}
    order: List[str] = [row.name for row in rows]
    edges: Set[Tuple[str, str]] = set()

    for row in rows:
        for src in row.inputs:
            if src != row.name:
                edges.add((src, row.name))
            if src not in type_by_name:
                type_by_name[src] = "SIGNAL"
                order.append(src)
        for tgt in row.outputs:
            if tgt != row.name:
                edges.add((row.name, tgt))
            if tgt not in type_by_name:
                type_by_name[tgt] = "SIGNAL"
                order.append(tgt)

    return type_by_name, edges, order


def dot_quote(text: str) -> str:
    return '"' + text.replace("\\", "\\\\").replace('"', '\\"') + '"'


def wrap_name(name: str, width: int = 22) -> str:
    if len(name) <= width:
        return name
    chunks = re.split(r"(_)", name)
    lines: List[str] = []
    current = ""
    for chunk in chunks:
        trial = current + chunk
        if len(trial) > width and current:
            lines.append(current.rstrip("_"))
            current = chunk.lstrip("_")
        else:
            current = trial
    if current:
        lines.append(current.rstrip("_"))
    return "\\n".join(lines) if lines else textwrap.fill(name, width).replace("\n", "\\n")


def classify_lane(name: str, typ: str, edges: Set[Tuple[str, str]]) -> str:
    if typ == "SRC":
        return "src"
    if typ == "SINK":
        return "sink"
    connected = [b if a == name else a for a, b in edges if a == name or b == name]
    bag = " ".join([name] + connected).lower()
    if typ in {"AND", "MUX"} or "rst" in bag or "reset" in bag:
        return "reset"
    return "clock"


def semantic_edge_color(src: str, tgt: str, style: dict) -> str:
    bag = f"{src} {tgt}".lower()
    colors = style["edges"]
    if "rst" in bag or "reset" in bag:
        return colors["reset"]
    if "clk" in bag or "clock" in bag or "div" in bag:
        return colors["clock"]
    if "cg" in bag or "gate" in bag or "en" in bag:
        return colors["gate"]
    return colors["default"]


def node_stmt(name: str, typ: str, style: dict) -> str:
    type_style = style["types"].get(typ, style["types"]["SIGNAL"])
    label = f"{wrap_name(name)}\\n{typ}"
    attrs = {
        "label": label,
        "shape": type_style.get("shape", "box"),
        "fillcolor": type_style["fill"],
        "color": type_style["border"],
        "fontcolor": type_style["font"],
    }
    parts = []
    for key, value in attrs.items():
        if key == "shape":
            parts.append(f"{key}={value}")
        else:
            parts.append(f'{key}="{value}"')
    if typ in {"SRC", "SINK"}:
        parts.append("penwidth=1.8")
    return f"    {dot_quote(name)} [{', '.join(parts)}];"


def build_dot(
    rows: Sequence[Row],
    title: Optional[str],
    style: dict,
    legend: bool = False,
    edge_color_mode: str = "semantic",
) -> str:
    type_by_name, edges, order = collect_graph(rows)

    lane_by_node = {
        name: classify_lane(name, typ, edges)
        for name, typ in type_by_name.items()
    }
    lanes = {"src": [], "clock": [], "reset": [], "sink": []}
    for name in order:
        lanes.setdefault(lane_by_node.get(name, "clock"), []).append(name)

    graph_style = style["graph"]
    graph_title = title or graph_style.get("title", "CRG Logic Map")

    lines: List[str] = ["digraph CRG {"]
    lines += [
        "  graph [",
        f'    label="{graph_title}",',
        "    labelloc=t,",
        "    fontsize=20,",
        f'    fontname="{graph_style.get("fontname", "Helvetica")}",',
        f'    bgcolor="{graph_style.get("bgcolor", "#FAFAFA")}",',
        f'    rankdir={graph_style.get("rankdir", "LR")},',
        f'    splines={graph_style.get("splines", "ortho")},',
        f'    nodesep={graph_style.get("nodesep", "0.38")},',
        f'    ranksep={graph_style.get("ranksep", "0.78")},',
        f'    pad={graph_style.get("pad", "0.28")},',
        "    compound=true,",
        "    newrank=true,",
        "    concentrate=false",
        "  ];",
        '  node [style="rounded,filled", fontname="Helvetica", fontsize=10, margin="0.10,0.06", penwidth=1.4, height=0.38];',
        '  edge [fontname="Helvetica", fontsize=9, arrowsize=0.65, penwidth=1.25, color="#64748B", fontcolor="#475569"];',
        "",
    ]

    for lane_key in ["src", "clock", "reset", "sink"]:
        cluster = style["clusters"].get(lane_key, {})
        lines += [
            f"  subgraph cluster_{lane_key} {{",
            f'    label="{cluster.get("label", lane_key)}";',
            "    fontsize=13;",
            '    fontname="Helvetica";',
            '    style="rounded,filled";',
            f'    fillcolor="{cluster.get("fill", "#FFFFFF")}";',
            f'    color="{cluster.get("color", "#E5E7EB")}";',
        ]
        for name in lanes.get(lane_key, []):
            lines.append(node_stmt(name, type_by_name[name], style))
        if lane_key in {"src", "sink"}:
            lines.append("    rank=same;")
        lines.append("  }")
        lines.append("")

    lane_rank = {"src": 0, "clock": 1, "reset": 2, "sink": 3}
    def edge_key(edge: Tuple[str, str]) -> Tuple[int, str, str]:
        src, tgt = edge
        return (lane_rank.get(lane_by_node.get(src, "clock"), 9), src, tgt)

    for src, tgt in sorted(edges, key=edge_key):
        color = semantic_edge_color(src, tgt, style) if edge_color_mode == "semantic" else style["edges"]["default"]
        attrs = [f'color="{color}"']
        if "rst" in f"{src} {tgt}".lower() or "reset" in f"{src} {tgt}".lower():
            attrs.append("penwidth=1.45")
        lines.append(f"  {dot_quote(src)} -> {dot_quote(tgt)} [{', '.join(attrs)}];")

    if legend:
        lines += [
            "",
            "  subgraph cluster_legend {",
            '    label="Legend"; fontsize=11; style="rounded,filled"; fillcolor="#FFFFFF"; color="#E5E7EB";',
        ]
        for typ in ["SRC", "BUF", "DIV", "SYNC", "CG", "AND", "MUX", "SINK"]:
            st = style["types"][typ]
            lines.append(
                f'    "legend_{typ}" [label="{typ}", shape={st["shape"]}, '
                f'fillcolor="{st["fill"]}", color="{st["border"]}", fontcolor="{st["font"]}", '
                "fontsize=9, width=0.55, height=0.28];"
            )
        lines += ["    rank=same;", "  }"]

    lines.append("}")
    return "\n".join(lines)



# ------------------------------
# Optimized fixed-lane layout
# ------------------------------

def improved_lane(name: str, typ: str, edges: Set[Tuple[str, str]]) -> str:
    """More CRG-aware lane classifier than the compact clustered view."""
    low = name.lower()
    if typ == "SRC":
        return "src"
    if typ == "SINK":
        return "sink_reset" if ("rst" in low or "reset" in low) else "sink_clock"
    outgoing = [b for a, b in edges if a == name]
    outgoing_bag = " ".join(outgoing).lower()
    if typ in {"AND", "MUX"} or "rst" in low or "reset" in low:
        return "reset"
    # A SYNC is reset-lane only when its own name or outputs are reset-like.
    # This keeps enable synchronizers such as single_sync in the clock/enable lane.
    if typ == "SYNC" and ("rst" in outgoing_bag or "reset" in outgoing_bag):
        return "reset"
    return "clock"


def dot_attrs(attrs: Dict[str, object]) -> str:
    parts: List[str] = []
    for key, value in attrs.items():
        if value is None:
            continue
        if isinstance(value, (int, float)):
            parts.append(f"{key}={value}")
        elif key in {"shape", "style", "arrowhead"} and str(value) in {"box", "oval", "diamond", "point", "plain", "none", "dashed", "solid", "rounded,filled"}:
            parts.append(f"{key}={value}")
        else:
            escaped = str(value).replace('"', '\\"')
            parts.append(f'{key}="{escaped}"')
    return ", ".join(parts)


def positioned_node_stmt(name: str, typ: str, style: dict, pos: Tuple[float, float], *, label: Optional[str] = None) -> str:
    if typ == "TAP":
        attrs = {
            "label": "",
            "shape": "point",
            "width": 0.055,
            "height": 0.055,
            "color": style["edges"].get("clock", "#2563EB"),
            "fillcolor": style["edges"].get("clock", "#2563EB"),
            "pos": f"{pos[0]*72:.1f},{pos[1]*72:.1f}!",
        }
        return f"  {dot_quote(name)} [{dot_attrs(attrs)}];"

    type_style = style["types"].get(typ, style["types"]["SIGNAL"])
    node_label = label or f"{wrap_name(name, 18)}\\n{typ}"
    attrs = {
        "label": node_label,
        "shape": type_style.get("shape", "box"),
        "fillcolor": type_style["fill"],
        "color": type_style["border"],
        "fontcolor": type_style["font"],
        "pos": f"{pos[0]*72:.1f},{pos[1]*72:.1f}!",
    }
    if typ in {"SRC", "SINK"}:
        attrs["penwidth"] = 1.8
    if typ == "AND":
        attrs["width"] = 0.9
        attrs["height"] = 0.62
    return f"  {dot_quote(name)} [{dot_attrs(attrs)}];"


def manual_crg_positions(nodes: Set[str]) -> Optional[Dict[str, Tuple[float, float]]]:
    """Use a stable CRG coordinate skeleton whenever the sheet matches the CRG pattern.

    The old version required every optional buffer to exist. That made smaller CRG
    sheets fall back to auto layout and visually drift from the template. This
    version checks only the semantic backbone, then returns coordinates for the
    nodes that are actually present. Missing optional nodes simply leave empty
    slots, preserving comparable diagrams across Excel variants.
    """
    backbone = {
        "clk_in", "clk_en", "chip_cold_rst_n", "sys_soft_rst_n", "ip_soft_rst_n",
        "u_crg_preserve_clk_buf", "div2", "u_crg_preserve_occ_buf", "single_sync",
        "cg1", "cg2", "and1", "mux1", "rst_sync1", "rst_sync2",
        "clk_aon", "clk_aon_fth", "clk_gate", "clk_gate_fth",
        "gate_rst_n", "gate_fth_rst_n", "aon_rst_n",
    }
    if not backbone.issubset(nodes):
        return None

    skeleton = {
        "clk_in": (0.0, 4.0), "clk_en": (0.0, 2.4), "chip_cold_rst_n": (0.0, 1.1),
        "sys_soft_rst_n": (0.0, -1.2), "ip_soft_rst_n": (0.0, -2.1),
        "u_crg_preserve_clk_buf": (2.0, 4.0), "div2": (3.75, 3.85),
        "u_crg_preserve_occ_buf": (5.6, 3.85), "single_sync": (5.6, 2.4),
        "clk_buf1": (7.55, 4.75), "clk_buf2": (7.55, 4.0),
        "cg1": (7.55, 3.25), "cg2": (7.55, 2.5),
        "clk_buf3": (9.25, 3.25), "clk_buf4": (9.25, 2.5),
        "and1": (2.0, -1.7), "mux1": (3.75, -1.7), "rst_sync1": (5.6, -1.7),
        "rst_sync2": (7.55, -0.65), "clk_buf5": (7.55, -2.45), "clk_buf6": (9.25, -0.65),
        "rst_buf1": (7.55, -2.45), "rst_buf2": (9.25, -0.65),
        "clk_aon_fth": (11.3, 4.75), "clk_aon": (11.3, 4.0),
        "clk_gate": (11.3, 3.25), "clk_gate_fth": (11.3, 2.5),
        "aon_rst_n": (11.3, -0.15), "aon_fth_rst_n": (11.3, -0.9),
        "gate_rst_n": (11.3, -1.7), "gate_fth_rst_n": (11.3, -2.45),
        "__tap__clk_aon": (8.75, 4.0),
    }
    return {name: pos for name, pos in skeleton.items() if name in nodes}


def auto_fixed_positions(
    type_by_name: Dict[str, str],
    render_edges: List[Tuple[str, str, Dict[str, object]]],
    order: List[str],
    style: dict,
) -> Dict[str, Tuple[float, float]]:
    """Deterministic fallback fixed-lane layout for other CRG-like logic sheets."""
    nodes = list(dict.fromkeys(order + [n for e in render_edges for n in e[:2]]))
    lane_by_node = {
        name: ("tap" if name.startswith("__tap__") else improved_lane(name, type_by_name.get(name, "TAP"), {(a, b) for a, b, _ in render_edges}))
        for name in nodes
    }

    adj: Dict[str, List[str]] = {n: [] for n in nodes}
    indeg: Dict[str, int] = {n: 0 for n in nodes}
    for src, tgt, _ in render_edges:
        adj.setdefault(src, []).append(tgt)
        indeg.setdefault(tgt, 0)
        indeg[tgt] += 1
        indeg.setdefault(src, 0)

    queue = [n for n in nodes if indeg.get(n, 0) == 0]
    queue.sort(key=lambda n: order.index(n) if n in order else 10_000)
    level = {n: 0 for n in nodes}
    seen = 0
    while queue:
        n = queue.pop(0)
        seen += 1
        for m in adj.get(n, []):
            level[m] = max(level.get(m, 0), level.get(n, 0) + 1)
            indeg[m] -= 1
            if indeg[m] == 0:
                queue.append(m)
                queue.sort(key=lambda x: (level.get(x, 0), order.index(x) if x in order else 10_000))
    if seen < len(nodes):
        # Cycle-safe fallback: keep Excel order and spread left-to-right.
        for idx, n in enumerate(nodes):
            level[n] = min(idx, 8)

    max_internal_level = max([level[n] for n in nodes if lane_by_node.get(n) not in {"src", "sink_clock", "sink_reset"}] or [1])
    for n in nodes:
        if lane_by_node.get(n) in {"sink_clock", "sink_reset"}:
            level[n] = max_internal_level + 2

    positions: Dict[str, Tuple[float, float]] = {}
    x_gap = 1.65

    clock_nodes = [n for n in nodes if lane_by_node.get(n) in {"clock", "tap"}]
    reset_nodes = [n for n in nodes if lane_by_node.get(n) == "reset"]
    clock_nodes.sort(key=lambda n: (level.get(n, 0), order.index(n) if n in order else 10_000, n))
    reset_nodes.sort(key=lambda n: (level.get(n, 0), order.index(n) if n in order else 10_000, n))

    for i, n in enumerate(clock_nodes):
        positions[n] = (level[n] * x_gap, 4.6 - (i % 5) * 0.82)
    for i, n in enumerate(reset_nodes):
        positions[n] = (level[n] * x_gap, -0.7 - (i % 5) * 0.82)

    # Sources align to the average y of their targets.
    src_nodes = [n for n in nodes if lane_by_node.get(n) == "src"]
    src_nodes.sort(key=lambda n: order.index(n) if n in order else 10_000)
    used_src_ys: List[float] = []
    for i, n in enumerate(src_nodes):
        target_ys = [positions[t][1] for s, t, _ in render_edges if s == n and t in positions]
        y = sum(target_ys) / len(target_ys) if target_ys else (4.2 - i * 0.9)
        while any(abs(y - old) < 0.42 for old in used_src_ys):
            y -= 0.55
        used_src_ys.append(y)
        positions[n] = (0.0, y)

    # Sinks align to the average y of their drivers.
    sink_nodes = [n for n in nodes if lane_by_node.get(n) in {"sink_clock", "sink_reset"}]
    sink_nodes.sort(key=lambda n: (-sum([positions[s][1] for s, t, _ in render_edges if t == n and s in positions] or [0]), n))
    used_sink_ys: List[float] = []
    for n in sink_nodes:
        source_ys = [positions[s][1] for s, t, _ in render_edges if t == n and s in positions]
        y = sum(source_ys) / len(source_ys) if source_ys else (2.5 if lane_by_node[n] == "sink_clock" else -1.5)
        while any(abs(y - old) < 0.45 for old in used_sink_ys):
            y -= 0.62
        used_sink_ys.append(y)
        positions[n] = ((max_internal_level + 2) * x_gap, y)

    return positions


def build_dot_optimized(
    rows: Sequence[Row],
    title: Optional[str],
    style: dict,
    legend: bool = False,
    edge_color_mode: str = "semantic",
) -> str:
    type_by_name, edges, order = collect_graph(rows)
    outgoing = {n: [t for s, t in edges if s == n] for n in type_by_name}
    reused_sinks = {n for n, typ in type_by_name.items() if typ == "SINK" and outgoing.get(n)}

    render_edges: List[Tuple[str, str, Dict[str, object]]] = []
    added_tap_to_sink: Set[str] = set()
    for src, tgt in sorted(edges):
        draw_src = f"__tap__{src}" if src in reused_sinks else src
        draw_tgt = f"__tap__{tgt}" if tgt in reused_sinks else tgt
        attrs: Dict[str, object] = {}
        if src in reused_sinks:
            tap_color = style["edges"].get("clock", "#2563EB") if ("clk" in src.lower() or "clock" in src.lower()) else semantic_edge_color(src, tgt, style)
            attrs.update({"style": "dashed", "label": src, "color": tap_color, "fontcolor": tap_color})
        render_edges.append((draw_src, draw_tgt, attrs))
        if tgt in reused_sinks and tgt not in added_tap_to_sink:
            render_edges.append((f"__tap__{tgt}", tgt, {}))
            added_tap_to_sink.add(tgt)

    for sink in reused_sinks:
        tap = f"__tap__{sink}"
        type_by_name[tap] = "TAP"
        if tap not in order:
            order.append(tap)

    manual = manual_crg_positions(set(type_by_name))
    positions = manual if manual else auto_fixed_positions(type_by_name, render_edges, order, style)

    graph_style = style["graph"]
    graph_title = title or f'{graph_style.get("title", "CRG Logic Map")} · Optimized'
    all_x = [p[0] for p in positions.values()] or [0, 10]
    all_y = [p[1] for p in positions.values()] or [0, 4]
    left_x, right_x = min(all_x), max(all_x)
    top_y, bottom_y = max(all_y), min(all_y)

    lines: List[str] = ["digraph CRG_Optimized {"]
    lines += [
        "  graph [",
        f'    label="{graph_title}",',
        "    labelloc=t,",
        "    fontsize=24,",
        f'    fontname="{graph_style.get("fontname", "Helvetica")}",',
        f'    bgcolor="{graph_style.get("bgcolor", "#FBFCFE")}",',
        "    outputorder=edgesfirst,",
        "    splines=ortho,",
        "    overlap=false,",
        "    margin=0.18,",
        "    pad=0.24,",
        "    nodesep=0.30,",
        "    ranksep=0.60,",
        "    concentrate=false,",
        "    compound=true",
        "  ];",
        '  node [style="rounded,filled", fontname="Helvetica", fontsize=10, margin="0.12,0.07", penwidth=1.4, height=0.42, fixedsize=false];',
        '  edge [fontname="Helvetica", fontsize=9, arrowsize=0.62, penwidth=1.22, color="#64748B", fontcolor="#475569"];',
        "",
        f'  input_lane [label="Inputs", shape=plain, fontname="Helvetica-Bold", fontsize=15, fontcolor="#334155", pos="{left_x*72:.1f},{(top_y+0.85)*72:.1f}!"];',
        f'  clock_lane [label="Clock / Enable Path", shape=plain, fontname="Helvetica-Bold", fontsize=15, fontcolor="#334155", pos="{((left_x+right_x)/2)*72:.1f},{(top_y+0.85)*72:.1f}!"];',
        f'  reset_lane [label="Reset Path", shape=plain, fontname="Helvetica-Bold", fontsize=15, fontcolor="#334155", pos="{((left_x+right_x)/2)*72:.1f},{0.15*72:.1f}!"];',
        f'  output_lane [label="Outputs", shape=plain, fontname="Helvetica-Bold", fontsize=15, fontcolor="#334155", pos="{right_x*72:.1f},{(top_y+0.85)*72:.1f}!"];',
        "",
    ]

    # Draw nodes in Excel order for deterministic SVG text order; taps after their related nodes.
    for name in order:
        if name in positions:
            lines.append(positioned_node_stmt(name, type_by_name[name], style, positions[name]))
    lines.append("")

    for src, tgt, extra in render_edges:
        color = semantic_edge_color(src.replace("__tap__", ""), tgt.replace("__tap__", ""), style) if edge_color_mode == "semantic" else style["edges"]["default"]
        attrs: Dict[str, object] = {"color": color}
        if "rst" in f"{src} {tgt}".lower() or "reset" in f"{src} {tgt}".lower():
            attrs["penwidth"] = 1.45
        attrs.update(extra)
        lines.append(f"  {dot_quote(src)} -> {dot_quote(tgt)} [{dot_attrs(attrs)}];")

    if legend:
        # Legend is intentionally omitted from the fixed-lane view to preserve layout compactness.
        pass
    lines.append("}")
    return "\n".join(lines)



# ------------------------------
# Pure-Python renderer (no Graphviz executable required)
# ------------------------------

def compute_optimized_render_model(rows: Sequence[Row], style: dict) -> Tuple[Dict[str, str], List[Tuple[str, str, Dict[str, object]]], List[str], Dict[str, Tuple[float, float]]]:
    """Return node types, rendered edges, render order, and deterministic coordinates."""
    type_by_name, edges, order = collect_graph(rows)
    outgoing = {n: [t for s, t in edges if s == n] for n in type_by_name}
    reused_sinks = {n for n, typ in type_by_name.items() if typ == "SINK" and outgoing.get(n)}

    render_edges: List[Tuple[str, str, Dict[str, object]]] = []
    added_tap_to_sink: Set[str] = set()
    for src, tgt in sorted(edges):
        draw_src = f"__tap__{src}" if src in reused_sinks else src
        draw_tgt = f"__tap__{tgt}" if tgt in reused_sinks else tgt
        attrs: Dict[str, object] = {}
        if src in reused_sinks:
            tap_color = style["edges"].get("clock", "#2563EB") if ("clk" in src.lower() or "clock" in src.lower()) else semantic_edge_color(src, tgt, style)
            attrs.update({"style": "dashed", "label": src, "color": tap_color, "fontcolor": tap_color})
        render_edges.append((draw_src, draw_tgt, attrs))
        if tgt in reused_sinks and tgt not in added_tap_to_sink:
            render_edges.append((f"__tap__{tgt}", tgt, {}))
            added_tap_to_sink.add(tgt)

    for sink in reused_sinks:
        tap = f"__tap__{sink}"
        type_by_name[tap] = "TAP"
        if tap not in order:
            order.append(tap)

    manual = manual_crg_positions(set(type_by_name))
    positions = manual if manual else auto_fixed_positions(type_by_name, render_edges, order, style)
    return type_by_name, render_edges, order, positions


def _hex_to_rgb(color: str) -> Tuple[int, int, int]:
    color = color.strip().lstrip('#')
    if len(color) == 3:
        color = ''.join(c*2 for c in color)
    return tuple(int(color[i:i+2], 16) for i in (0, 2, 4))  # type: ignore[return-value]


def _node_size(name: str, typ: str) -> Tuple[float, float]:
    if typ == "TAP":
        return (0.10, 0.10)
    label_lines = wrap_name(name, 18).split('\\n') + [typ]
    longest = max(len(x) for x in label_lines)
    width = max(1.18, min(2.15, 0.105 * longest + 0.45))
    height = 0.58 if typ != "AND" else 0.72
    if len(label_lines) > 2:
        height += 0.18 * (len(label_lines) - 2)
    return width, height


def _edge_ports(src: str, tgt: str, positions: Dict[str, Tuple[float, float]], type_by_name: Dict[str, str]) -> Tuple[Tuple[float, float], Tuple[float, float]]:
    sx, sy = positions[src]
    tx, ty = positions[tgt]
    sw, sh = _node_size(src, type_by_name.get(src, "SIGNAL"))
    tw, th = _node_size(tgt, type_by_name.get(tgt, "SIGNAL"))
    # Left-to-right is the normal CRG flow; for vertical reset/feedback branches, use nearest side.
    if tx >= sx:
        return (sx + sw / 2, sy), (tx - tw / 2, ty)
    return (sx - sw / 2, sy), (tx + tw / 2, ty)


def _orthogonal_points(start: Tuple[float, float], end: Tuple[float, float]) -> List[Tuple[float, float]]:
    sx, sy = start
    ex, ey = end
    if abs(sy - ey) < 0.06:
        return [start, end]
    mx = (sx + ex) / 2
    return [start, (mx, sy), (mx, ey), end]


def _bounds(positions: Dict[str, Tuple[float, float]], type_by_name: Dict[str, str]) -> Tuple[float, float, float, float]:
    min_x = min_y = float('inf')
    max_x = max_y = float('-inf')
    for name, (x, y) in positions.items():
        w, h = _node_size(name, type_by_name.get(name, "SIGNAL"))
        min_x = min(min_x, x - w / 2)
        max_x = max(max_x, x + w / 2)
        min_y = min(min_y, y - h / 2)
        max_y = max(max_y, y + h / 2)
    return min_x, min_y, max_x, max_y


def _svg_escape(text: object) -> str:
    return str(text).replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')


def render_pure_svg(rows: Sequence[Row], svg_path: Path, title: Optional[str], style: dict, edge_color_mode: str = "semantic") -> None:
    type_by_name, render_edges, order, positions = compute_optimized_render_model(rows, style)
    min_x, min_y, max_x, max_y = _bounds(positions, type_by_name)
    scale = 96.0
    margin_l, margin_r, margin_t, margin_b = 90.0, 90.0, 92.0, 70.0
    width = int((max_x - min_x) * scale + margin_l + margin_r)
    height = int((max_y - min_y) * scale + margin_t + margin_b)

    def X(x: float) -> float:
        return margin_l + (x - min_x) * scale
    def Y(y: float) -> float:
        return margin_t + (max_y - y) * scale

    graph_title = title or f'{style["graph"].get("title", "CRG Logic Map")} · Pure Python'
    lines: List[str] = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        '<defs>',
        '<marker id="arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="#64748B"/></marker>',
        '<filter id="shadow" x="-8%" y="-8%" width="116%" height="116%"><feDropShadow dx="0" dy="1.2" stdDeviation="1.1" flood-color="#94A3B8" flood-opacity="0.25"/></filter>',
        '</defs>',
        f'<rect x="0" y="0" width="{width}" height="{height}" fill="{_svg_escape(style["graph"].get("bgcolor", "#FBFCFE"))}"/>',
        f'<text x="{width/2:.1f}" y="36" text-anchor="middle" font-family="Helvetica, Arial, sans-serif" font-size="24" font-weight="700" fill="#0F172A">{_svg_escape(graph_title)}</text>',
    ]

    top_y = max_y + 0.78
    reset_label_y = 0.15
    lanes = [
        ("Inputs", min_x + 0.45, top_y),
        ("Clock / Enable Path", (min_x + max_x) / 2, top_y),
        ("Reset Path", (min_x + max_x) / 2, reset_label_y),
        ("Outputs", max_x - 0.45, top_y),
    ]
    for label, x, y in lanes:
        lines.append(f'<text x="{X(x):.1f}" y="{Y(y):.1f}" text-anchor="middle" font-family="Helvetica, Arial, sans-serif" font-size="15" font-weight="700" fill="#334155">{_svg_escape(label)}</text>')

    # Edges first.
    for src, tgt, extra in render_edges:
        if src not in positions or tgt not in positions:
            continue
        base_src = src.replace("__tap__", "")
        base_tgt = tgt.replace("__tap__", "")
        color = str(extra.get("color") or (semantic_edge_color(base_src, base_tgt, style) if edge_color_mode == "semantic" else style["edges"]["default"]))
        start, end = _edge_ports(src, tgt, positions, type_by_name)
        pts = _orthogonal_points(start, end)
        pstr = " ".join(f"{X(x):.1f},{Y(y):.1f}" for x, y in pts)
        dash = ' stroke-dasharray="5 4"' if extra.get("style") == "dashed" else ""
        lines.append(f'<polyline points="{pstr}" fill="none" stroke="{_svg_escape(color)}" stroke-width="1.7" stroke-linejoin="round" stroke-linecap="round" marker-end="url(#arrow)"{dash}/>')
        if extra.get("label"):
            lx = X((pts[0][0] + pts[-1][0]) / 2)
            ly = Y((pts[0][1] + pts[-1][1]) / 2) - 5
            lines.append(f'<text x="{lx:.1f}" y="{ly:.1f}" text-anchor="middle" font-family="Helvetica, Arial, sans-serif" font-size="10" fill="{_svg_escape(color)}">{_svg_escape(extra["label"])}</text>')

    # Nodes.
    for name in order:
        if name not in positions:
            continue
        typ = type_by_name.get(name, "SIGNAL")
        x, y = positions[name]
        cx, cy = X(x), Y(y)
        w, h = _node_size(name, typ)
        wp, hp = w * scale, h * scale
        if typ == "TAP":
            lines.append(f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="3.2" fill="#2563EB" stroke="#2563EB"/>')
            continue
        st = style["types"].get(typ, style["types"]["SIGNAL"])
        fill, border, font = st["fill"], st["border"], st["font"]
        shape = st.get("shape", "box")
        if shape == "oval":
            lines.append(f'<ellipse cx="{cx:.1f}" cy="{cy:.1f}" rx="{wp/2:.1f}" ry="{hp/2:.1f}" fill="{fill}" stroke="{border}" stroke-width="1.8" filter="url(#shadow)"/>')
        elif shape == "diamond":
            pts = [(cx, cy-hp/2), (cx+wp/2, cy), (cx, cy+hp/2), (cx-wp/2, cy)]
            pstr = " ".join(f"{px:.1f},{py:.1f}" for px, py in pts)
            lines.append(f'<polygon points="{pstr}" fill="{fill}" stroke="{border}" stroke-width="1.8" filter="url(#shadow)"/>')
        else:
            lines.append(f'<rect x="{cx-wp/2:.1f}" y="{cy-hp/2:.1f}" width="{wp:.1f}" height="{hp:.1f}" rx="8" ry="8" fill="{fill}" stroke="{border}" stroke-width="1.8" filter="url(#shadow)"/>')
        label_lines = wrap_name(name, 18).split('\\n') + [typ]
        line_h = 13
        start_y = cy - (len(label_lines)-1) * line_h / 2 + 4
        for i, txt in enumerate(label_lines):
            weight = "700" if i == len(label_lines) - 1 else "500"
            size = 10 if i == len(label_lines) - 1 else 11
            lines.append(f'<text x="{cx:.1f}" y="{start_y + i*line_h:.1f}" text-anchor="middle" font-family="Helvetica, Arial, sans-serif" font-size="{size}" font-weight="{weight}" fill="{font}">{_svg_escape(txt)}</text>')

    lines.append('</svg>')
    svg_path.write_text("\n".join(lines), encoding="utf-8")


def _load_pillow_font(size: int, bold: bool = False):
    try:
        from PIL import ImageFont
        candidates = [
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
            "/System/Library/Fonts/Supplemental/Arial Bold.ttf" if bold else "/System/Library/Fonts/Supplemental/Arial.ttf",
            "C:/Windows/Fonts/arialbd.ttf" if bold else "C:/Windows/Fonts/arial.ttf",
        ]
        for cand in candidates:
            if Path(cand).exists():
                return ImageFont.truetype(cand, size=size)
        return ImageFont.load_default()
    except Exception:
        return None


def render_pure_png(rows: Sequence[Row], png_path: Path, title: Optional[str], style: dict, edge_color_mode: str = "semantic") -> None:
    try:
        from PIL import Image, ImageDraw
    except ImportError as exc:
        raise RuntimeError("PNG fallback requires Pillow. Install with: pip install pillow. SVG output does not require Pillow.") from exc

    type_by_name, render_edges, order, positions = compute_optimized_render_model(rows, style)
    min_x, min_y, max_x, max_y = _bounds(positions, type_by_name)
    scale = 140.0
    margin_l, margin_r, margin_t, margin_b = 130.0, 130.0, 130.0, 95.0
    width = int((max_x - min_x) * scale + margin_l + margin_r)
    height = int((max_y - min_y) * scale + margin_t + margin_b)

    def X(x: float) -> float:
        return margin_l + (x - min_x) * scale
    def Y(y: float) -> float:
        return margin_t + (max_y - y) * scale

    img = Image.new("RGB", (width, height), _hex_to_rgb(style["graph"].get("bgcolor", "#FBFCFE")))
    draw = ImageDraw.Draw(img)
    font_title = _load_pillow_font(31, True)
    font_lane = _load_pillow_font(19, True)
    font_node = _load_pillow_font(15, False)
    font_type = _load_pillow_font(14, True)
    font_edge = _load_pillow_font(13, False)

    def center_text(text: str, xy: Tuple[float, float], font, fill):
        bbox = draw.textbbox((0, 0), text, font=font)
        draw.text((xy[0] - (bbox[2]-bbox[0])/2, xy[1] - (bbox[3]-bbox[1])/2), text, font=font, fill=fill)

    graph_title = title or f'{style["graph"].get("title", "CRG Logic Map")} · Pure Python'
    center_text(graph_title, (width/2, 46), font_title, _hex_to_rgb("#0F172A"))
    top_y = max_y + 0.78
    for label, x, y in [("Inputs", min_x + 0.45, top_y), ("Clock / Enable Path", (min_x+max_x)/2, top_y), ("Reset Path", (min_x+max_x)/2, 0.15), ("Outputs", max_x - 0.45, top_y)]:
        center_text(label, (X(x), Y(y)), font_lane, _hex_to_rgb("#334155"))

    def draw_arrow(points, color, dashed=False):
        rgb = _hex_to_rgb(color)
        # draw segments, optionally dashed
        for (x1, y1), (x2, y2) in zip(points, points[1:]):
            x1, y1, x2, y2 = X(x1), Y(y1), X(x2), Y(y2)
            if dashed:
                length = math.hypot(x2-x1, y2-y1)
                if length == 0:
                    continue
                ux, uy = (x2-x1)/length, (y2-y1)/length
                d = 0.0
                while d < length:
                    e = min(d+8, length)
                    draw.line((x1+ux*d, y1+uy*d, x1+ux*e, y1+uy*e), fill=rgb, width=2)
                    d += 14
            else:
                draw.line((x1, y1, x2, y2), fill=rgb, width=2)
        # arrow head at final segment
        (px, py), (qx, qy) = points[-2], points[-1]
        px, py, qx, qy = X(px), Y(py), X(qx), Y(qy)
        ang = math.atan2(qy-py, qx-px)
        size = 9
        a1, a2 = ang + math.pi*0.82, ang - math.pi*0.82
        head = [(qx, qy), (qx + size*math.cos(a1), qy + size*math.sin(a1)), (qx + size*math.cos(a2), qy + size*math.sin(a2))]
        draw.polygon(head, fill=rgb)

    for src, tgt, extra in render_edges:
        if src not in positions or tgt not in positions:
            continue
        base_src = src.replace("__tap__", "")
        base_tgt = tgt.replace("__tap__", "")
        color = str(extra.get("color") or (semantic_edge_color(base_src, base_tgt, style) if edge_color_mode == "semantic" else style["edges"]["default"]))
        points = _orthogonal_points(*_edge_ports(src, tgt, positions, type_by_name))
        draw_arrow(points, color, dashed=(extra.get("style") == "dashed"))
        if extra.get("label"):
            lx = X((points[0][0] + points[-1][0]) / 2)
            ly = Y((points[0][1] + points[-1][1]) / 2) - 12
            center_text(str(extra["label"]), (lx, ly), font_edge, _hex_to_rgb(color))

    for name in order:
        if name not in positions:
            continue
        typ = type_by_name.get(name, "SIGNAL")
        cx, cy = X(positions[name][0]), Y(positions[name][1])
        if typ == "TAP":
            draw.ellipse((cx-4, cy-4, cx+4, cy+4), fill=_hex_to_rgb("#2563EB"), outline=_hex_to_rgb("#2563EB"))
            continue
        w, h = _node_size(name, typ)
        wp, hp = w * scale, h * scale
        st = style["types"].get(typ, style["types"]["SIGNAL"])
        fill, border, font = _hex_to_rgb(st["fill"]), _hex_to_rgb(st["border"]), _hex_to_rgb(st["font"])
        shape = st.get("shape", "box")
        box = (cx-wp/2, cy-hp/2, cx+wp/2, cy+hp/2)
        if shape == "oval":
            draw.ellipse(box, fill=fill, outline=border, width=2)
        elif shape == "diamond":
            pts = [(cx, cy-hp/2), (cx+wp/2, cy), (cx, cy+hp/2), (cx-wp/2, cy)]
            draw.polygon(pts, fill=fill, outline=border)
            draw.line(pts+[pts[0]], fill=border, width=2)
        else:
            draw.rounded_rectangle(box, radius=12, fill=fill, outline=border, width=2)
        label_lines = wrap_name(name, 18).split('\\n') + [typ]
        line_h = 17
        sy = cy - (len(label_lines)-1) * line_h / 2
        for i, txt in enumerate(label_lines):
            center_text(txt, (cx, sy + i*line_h), font_type if i == len(label_lines)-1 else font_node, font)

    img.save(png_path)


def render_pure_outputs(rows: Sequence[Row], base_path: Path, formats: Sequence[str], title: Optional[str], style: dict, edge_color_mode: str = "semantic") -> List[Path]:
    outputs: List[Path] = []
    for fmt in formats:
        fmt = fmt.lower().strip()
        if fmt == "svg":
            out = base_path.with_suffix(".svg")
            render_pure_svg(rows, out, title, style, edge_color_mode=edge_color_mode)
            outputs.append(out)
        elif fmt == "png":
            out = base_path.with_suffix(".png")
            render_pure_png(rows, out, title, style, edge_color_mode=edge_color_mode)
            outputs.append(out)
        elif fmt == "dot":
            # DOT is already written by main; keep this as a no-op output reference.
            outputs.append(base_path.with_suffix(".dot"))
        else:
            raise RuntimeError(f"Pure-Python backend supports only svg/png/dot, not {fmt!r}.")
    return outputs


def load_style(path: Optional[Path]) -> dict:
    if not path:
        return DEFAULT_STYLE
    with path.open("r", encoding="utf-8") as f:
        user_style = json.load(f)

    # Shallow/deep merge enough for this config.
    merged = json.loads(json.dumps(DEFAULT_STYLE))
    for group, value in user_style.items():
        if isinstance(value, dict) and isinstance(merged.get(group), dict):
            for key, subvalue in value.items():
                if isinstance(subvalue, dict) and isinstance(merged[group].get(key), dict):
                    merged[group][key].update(subvalue)
                else:
                    merged[group][key] = subvalue
        else:
            merged[group] = value
    return merged


def render_with_dot(dot_path: Path, formats: Sequence[str], engine: str = "dot") -> List[Path]:
    engine = engine.lower().strip()
    graphviz_bin = "neato" if engine == "neato" else "dot"
    graphviz_path = shutil.which(graphviz_bin)
    if not graphviz_path:
        raise RuntimeError(f"Graphviz executable {graphviz_bin!r} not found in PATH. Install Graphviz and retry.")

    outputs: List[Path] = []
    for fmt in formats:
        fmt = fmt.lower().strip()
        if not fmt:
            continue
        output_path = dot_path.with_suffix(f".{fmt}")
        cmd = [graphviz_path]
        if engine == "neato":
            cmd.append("-n2")
        cmd += [f"-T{fmt}", str(dot_path), "-o", str(output_path)]
        proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
        if proc.returncode != 0:
            raise RuntimeError(f"{graphviz_bin} failed for format {fmt}:\n{proc.stderr}")
        outputs.append(output_path)
    return outputs


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Render CRG logic from Excel to Graphviz DOT/SVG/PNG.")
    parser.add_argument("--input", "-i", required=True, type=Path, help="Input .xlsx file.")
    parser.add_argument("--sheet", "-s", default=None, help="Sheet name. Default: first sheet.")
    parser.add_argument("--outdir", "-o", type=Path, default=Path("out"), help="Output directory.")
    parser.add_argument("--name", default=None, help="Base output name. Default: input file stem.")
    parser.add_argument("--title", default=None, help="Graph title.")
    parser.add_argument("--style", type=Path, default=None, help="Optional style JSON file.")
    parser.add_argument("--formats", default="png,svg", help="Comma-separated output formats, e.g. png,svg,pdf.")
    parser.add_argument("--legend", action="store_true", help="Add type legend cluster.")
    parser.add_argument("--edge-color-mode", choices=["semantic", "neutral"], default="semantic")
    parser.add_argument("--layout", choices=["optimized", "clustered"], default="optimized", help="optimized uses a fixed-lane layout; clustered uses automatic dot clusters.")
    parser.add_argument("--backend", choices=["auto", "graphviz", "pure"], default="auto", help="auto: use Graphviz when available, otherwise pure Python. graphviz: require dot/neato. pure: no Graphviz executable required.")
    return parser.parse_args(argv)


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = parse_args(argv)
    rows = load_rows(args.input, args.sheet)
    style = load_style(args.style)

    args.outdir.mkdir(parents=True, exist_ok=True)
    base_name = args.name or args.input.stem
    dot_path = args.outdir / f"{base_name}.dot"

    if args.layout == "optimized":
        dot_text = build_dot_optimized(rows, args.title, style, legend=args.legend, edge_color_mode=args.edge_color_mode)
        engine = "neato"
    else:
        dot_text = build_dot(rows, args.title, style, legend=args.legend, edge_color_mode=args.edge_color_mode)
        engine = "dot"
    dot_path.write_text(dot_text, encoding="utf-8")

    formats = [f.strip() for f in args.formats.split(",") if f.strip()]
    outputs: List[Path] = []
    backend_used = args.backend
    if args.backend == "pure":
        outputs = render_pure_outputs(rows, dot_path, formats, args.title, style, edge_color_mode=args.edge_color_mode)
    elif args.backend == "graphviz":
        outputs = render_with_dot(dot_path, formats, engine=engine)
    else:
        graphviz_bin = "neato" if engine == "neato" else "dot"
        if shutil.which(graphviz_bin):
            outputs = render_with_dot(dot_path, formats, engine=engine)
            backend_used = "graphviz"
        else:
            pure_formats = [f for f in formats if f.lower() in {"svg", "png", "dot"}]
            outputs = render_pure_outputs(rows, dot_path, pure_formats, args.title, style, edge_color_mode=args.edge_color_mode)
            backend_used = "pure"

    print(f"Generated with backend: {backend_used}")
    print(f"  {dot_path}")
    for path in outputs:
        if path != dot_path:
            print(f"  {path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
