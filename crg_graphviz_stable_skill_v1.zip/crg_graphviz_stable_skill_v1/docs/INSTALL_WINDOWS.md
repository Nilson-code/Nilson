# Windows 安装说明

## 1. 安装 Python

建议 Python 3.9 或更高版本。

确认：

```bat
python --version
```

## 2. 安装 Python 依赖

进入 skill 文件夹：

```bat
pip install -r requirements.txt
```

## 3. 安装 Graphviz

安装完成后，需要让命令行能找到 `dot.exe`。

检查：

```bat
dot -V
```

能看到版本号就说明成功。

如果提示不是内部或外部命令，需要把类似下面的目录加入系统环境变量 PATH：

```text
C:\Program Files\Graphviz\bin
```

然后重新打开 CMD / PowerShell。

## 4. 一键运行示例

双击：

```text
run_example.bat
```

或者命令行运行：

```bat
python crg_stable_graphviz_generator.py -i examples\component_example_logic_revised.xlsx -o outputs -b demo --compact
```
