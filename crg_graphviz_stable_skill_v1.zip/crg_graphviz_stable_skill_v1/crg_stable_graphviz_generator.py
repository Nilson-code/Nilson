#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
crg_stable_graphviz_generator.py

Stable CRG / clock-reset / logic diagram generator from Excel.

Input Excel columns:
    NAME, TYPE, IN1, IN2, IN3, IN4, OUT1, OUT2, OUT3, OUT4, NOTE

Output:
    .dot, .png, .svg, report.txt

Design philosophy:
    - SRC fixed to the left.
    - SINK fixed to the right.
    - Middle logic is NOT over-ranked; Graphviz places it naturally.
    - One invisible guide chain stabilizes the main clock path.
    - Reset edges are red dashed, enable/control edges are green dotted.
    - Ordinary clock/data edges are gray solid.

Dependencies:
    pip install openpyxl
    Graphviz system command: dot
"""

from __future__ import annotations

import argparse
import re
import shutil
import subprocess
from pathlib import Path
from typing import Dict, List, Tuple, Iterable, Optional

from openpyxl import load_workbook


TYPE_COLOR = {
    "SRC":   ("#2F75B5", "#BFE3FF"),
    "SINK":  ("#548235", "#E2F0D9"),
    "BUF":   ("#BF9000", "#FFF2CC"),
    "PLL":   ("#548235", "#E2F0D9"),
    "DIV":   ("#C65911", "#FCE4D6"),
    "SYNC":  ("#7030A0", "#E4DFEC"),
    "CG":    ("#5B9BD5", "#DDEBF7"),
    "OCC":   ("#5B9BD5", "#DDEBF7"),
    "MUX":   ("#BF9000", "#FFF2CC"),
    "AND":   ("#BF9000", "#FFF2CC"),
    "OR":    ("#C00000", "#F8CBAD"),
    "INV":   ("#7F6000", "#FFF2CC"),
    "WIRE":  ("#7F7F7F", "#E7E6E6"),
    "LOGIC": ("#7F6000", "#FFF2CC"),
}

TYPE_PRIORITY = {
    "BUF": 1,
    "PLL": 2,
    "DIV": 3,
    "MUX": 4,
    "AND": 4,
    "OR": 4,
    "INV": 4,
    "SYNC": 5,
    "CG": 6,
    "OCC": 6,
    "LOGIC": 7,
    "WIRE": 8,
}


def q(name: str) -> str:
    return '"' + str(name).replace("\\", "\\\\").replace('"', '\\"') + '"'


def norm_type(t: Optional[str]) -> str:
    if not t:
        return "LOGIC"
    s = str(t).strip().upper()
    aliases = {
        "CLOCK_GATE": "CG",
        "CLK_GATE": "CG",
        "GATE": "CG",
        "CLKGATE": "CG",
        "RESET_SYNC": "SYNC",
        "RST_SYNC": "SYNC",
        "SYNCHRONIZER": "SYNC",
        "SOURCE": "SRC",
        "OUTPUT": "SINK",
        "OUT": "SINK",
        "CLOCK_OUT": "SINK",
        "CLK_OUT": "SINK",
        "COMB": "LOGIC",
    }
    return aliases.get(s, s)


def is_reset_name(n: str) -> bool:
    s = n.lower()
    return "rst" in s or "reset" in s


def is_enable_name(n: str) -> bool:
    s = n.lower()
    return (
        "clk_en" in s
        or s.endswith("_en")
        or "_en_" in s
        or "enable" in s
        or "scan_en" in s
    )


def is_clockish_name(n: str) -> bool:
    s = n.lower()
    return any(k in s for k in ["clk", "clock", "cg", "div", "pll", "aon", "gate"])


def clean_cell(v) -> Optional[str]:
    if v is None:
        return None
    s = str(v).strip()
    return s if s else None


def parse_excel(xlsx_path: Path, sheet_name: Optional[str] = None):
    wb = load_workbook(xlsx_path, data_only=True)
    ws = wb[sheet_name] if sheet_name else wb[wb.sheetnames[0]]

    rows = list(ws.iter_rows(values_only=True))
    header_idx = None
    headers = None

    for i, row in enumerate(rows):
        row_upper = [str(x).strip().upper() if x is not None else "" for x in row]
        if "NAME" in row_upper and "TYPE" in row_upper:
            header_idx = i
            headers = row_upper
            break

    if header_idx is None or headers is None:
        raise ValueError("Excel must contain NAME and TYPE columns.")

    col = {h: idx for idx, h in enumerate(headers) if h}

    def cell(row, key):
        idx = col.get(key)
        if idx is None or idx >= len(row):
            return None
        return clean_cell(row[idx])

    nodes: Dict[str, str] = {}
    row_order: Dict[str, int] = {}
    data_rows = []

    for r_i, row in enumerate(rows[header_idx + 1 :], start=header_idx + 2):
        name = cell(row, "NAME")
        typ = cell(row, "TYPE")
        if not name:
            continue
        nodes[name] = norm_type(typ)
        row_order[name] = r_i
        data_rows.append(row)

    in_cols = sorted([h for h in headers if re.fullmatch(r"IN\d+", h)], key=lambda x: int(x[2:]))
    out_cols = sorted([h for h in headers if re.fullmatch(r"OUT\d+", h)], key=lambda x: int(x[3:]))

    edges: List[Tuple[str, str]] = []
    edge_set = set()

    def add_edge(a, b):
        if a and b and a != b and (a, b) not in edge_set:
            edge_set.add((a, b))
            edges.append((a, b))

    for row in data_rows:
        name = cell(row, "NAME")
        if not name:
            continue

        for c in in_cols:
            src = cell(row, c)
            if src:
                nodes.setdefault(src, "WIRE")
                row_order.setdefault(src, 9999 + len(row_order))
                add_edge(src, name)

        for c in out_cols:
            dst = cell(row, c)
            if dst:
                nodes.setdefault(dst, "SINK")
                row_order.setdefault(dst, 9999 + len(row_order))
                add_edge(name, dst)

    succ = build_succ(edges)
    for n in list(nodes):
        if nodes[n] == "WIRE" and not succ.get(n):
            nodes[n] = "SINK"

    return nodes, edges, row_order


def build_succ(edges: Iterable[Tuple[str, str]]) -> Dict[str, List[str]]:
    succ: Dict[str, List[str]] = {}
    for a, b in edges:
        succ.setdefault(a, []).append(b)
    return succ


def sort_src(nodes, row_order):
    srcs = [n for n, t in nodes.items() if t == "SRC"]
    return sorted(
        srcs,
        key=lambda n: (
            0 if is_clockish_name(n) and not is_reset_name(n) else 1 if is_reset_name(n) else 2,
            row_order.get(n, 99999),
            n,
        ),
    )


def sort_sink(nodes, row_order):
    sinks = [n for n, t in nodes.items() if t == "SINK"]
    return sorted(
        sinks,
        key=lambda n: (
            0 if is_clockish_name(n) and not is_reset_name(n) else 1 if is_reset_name(n) else 2,
            row_order.get(n, 99999),
            n,
        ),
    )


def sort_middle(nodes, row_order):
    mids = [n for n, t in nodes.items() if t not in {"SRC", "SINK"}]
    return sorted(
        mids,
        key=lambda n: (
            1 if is_reset_name(n) else 0,
            TYPE_PRIORITY.get(nodes.get(n, "LOGIC"), 99),
            row_order.get(n, 99999),
            n,
        ),
    )


def edge_style(a: str, b: str, nodes: Dict[str, str], sink_constraint: bool = False) -> str:
    attrs = []
    if is_enable_name(a) or is_enable_name(b):
        attrs += ['color="#6AA84F"', 'style="dotted"', "penwidth=1.2"]
    elif is_reset_name(a) or is_reset_name(b):
        attrs += ['color="#B85450"', 'style="dashed"', "penwidth=1.2"]
    else:
        attrs += ['color="#666666"', "penwidth=1.25"]

    if nodes.get(b) == "SINK" and not sink_constraint:
        attrs += ["constraint=false", "weight=1"]

    return "[" + ", ".join(attrs) + "]"


def choose_main_backbone(nodes, edges, row_order) -> List[str]:
    """
    Choose a lightweight main clock chain for invisible stabilization.
    This avoids the bad style where every stage is forced into hard ranks.
    """
    succ = build_succ(edges)
    starts = [n for n, t in nodes.items() if t == "SRC" and is_clockish_name(n) and not is_reset_name(n)]
    if not starts:
        starts = [n for n, t in nodes.items() if t == "SRC"]

    def next_score(v):
        typ = nodes.get(v, "LOGIC")
        return (
            0 if typ in {"BUF", "PLL"} else
            1 if typ == "DIV" else
            2 if typ == "SYNC" else
            3 if typ in {"CG", "OCC"} else
            4 if typ == "SINK" and is_clockish_name(v) else
            9,
            row_order.get(v, 99999),
            v,
        )

    best_chain = []
    for st in sorted(starts, key=lambda n: row_order.get(n, 99999)):
        chain = [st]
        cur = st
        seen = {cur}
        for _ in range(30):
            candidates = [v for v in succ.get(cur, []) if v not in seen and not is_reset_name(v)]
            candidates.sort(key=next_score)
            if not candidates:
                break
            nxt = candidates[0]
            chain.append(nxt)
            seen.add(nxt)
            cur = nxt
            if nodes.get(cur) == "SINK":
                break
        if len(chain) > len(best_chain):
            best_chain = chain

    return [n for n in best_chain if nodes.get(n) != "SINK"]


def generate_dot(
    nodes: Dict[str, str],
    edges: List[Tuple[str, str]],
    row_order: Dict[str, int],
    title: str,
    nodesep: float = 0.55,
    ranksep: float = 1.05,
    sink_constraint: bool = False,
) -> str:
    src_nodes = sort_src(nodes, row_order)
    sink_nodes = sort_sink(nodes, row_order)
    mid_nodes = sort_middle(nodes, row_order)
    main_backbone = choose_main_backbone(nodes, edges, row_order)

    left_anchor = src_nodes[0] if src_nodes else None
    right_anchor = sink_nodes[0] if sink_nodes else None

    lines = []
    lines.append("digraph G {")
    lines.append(
        f'  graph [rankdir=LR, splines=ortho, nodesep={nodesep:.2f}, ranksep={ranksep:.2f}, '
        f'pad=0.18, margin=0.04, overlap=false, bgcolor=white, '
        f'labelloc=t, label="{title}", fontsize=22, fontname="Arial", '
        f'newrank=true, ordering=out];'
    )
    lines.append(
        '  node [shape=box, style="rounded,filled", fontname="Arial", '
        'fontsize=11, margin="0.08,0.05", penwidth=1.15];'
    )
    lines.append('  edge [arrowsize=0.7, fontname="Arial", fontsize=8];')
    lines.append("")

    lines.append('  subgraph cluster_src {')
    lines.append('    label="SRC"; style="rounded,dashed"; color="#D9D9D9";')
    lines.append("    rank=source;")
    for n in src_nodes:
        stroke, fill = TYPE_COLOR.get(nodes[n], TYPE_COLOR["LOGIC"])
        lines.append(f'    {q(n)} [label="{n}\\n<{nodes[n]}>", fillcolor="{fill}", color="{stroke}"];')
    lines.append("  }")
    lines.append("")

    for n in mid_nodes:
        typ = nodes.get(n, "LOGIC")
        stroke, fill = TYPE_COLOR.get(typ, TYPE_COLOR["LOGIC"])
        lines.append(f'  {q(n)} [label="{n}\\n<{typ}>", fillcolor="{fill}", color="{stroke}"];')
    lines.append("")

    lines.append('  subgraph cluster_sink {')
    lines.append('    label="SINK"; style="rounded,dashed"; color="#D9D9D9";')
    lines.append("    rank=sink;")
    for n in sink_nodes:
        stroke, fill = TYPE_COLOR.get(nodes[n], TYPE_COLOR["SINK"])
        lines.append(f'    {q(n)} [label="{n}\\n<{nodes[n]}>", fillcolor="{fill}", color="{stroke}"];')
    lines.append("  }")
    lines.append("")

    # Keep vertical order inside SRC/SINK but do not let these helper edges distort LR placement.
    for group in [src_nodes, sink_nodes]:
        for a, b in zip(group[:-1], group[1:]):
            lines.append(f"  {q(a)} -> {q(b)} [style=invis, weight=80, constraint=false];")

    # Light main path stabilization.
    for a, b in zip(main_backbone[:-1], main_backbone[1:]):
        lines.append(f"  {q(a)} -> {q(b)} [style=invis, weight=25];")

    # LR guide chain: SRC -> backbone -> SINK.
    if left_anchor and right_anchor:
        guide = [left_anchor]
        for n in main_backbone:
            if n not in guide and nodes.get(n) not in {"SRC", "SINK"}:
                guide.append(n)
        if len(guide) == 1 and mid_nodes:
            guide.append(mid_nodes[0])
        guide.append(right_anchor)

        for a, b in zip(guide[:-1], guide[1:]):
            lines.append(f"  {q(a)} -> {q(b)} [style=invis, weight=120, minlen=1];")

    lines.append("")
    for a, b in edges:
        lines.append(f"  {q(a)} -> {q(b)} {edge_style(a, b, nodes, sink_constraint=sink_constraint)};")

    lines.append("}")
    return "\n".join(lines)


def render_graphviz(dot_path: Path, png_path: Path, svg_path: Path):
    dot_bin = shutil.which("dot")
    if not dot_bin:
        raise RuntimeError(
            "Graphviz 'dot' executable not found. Install Graphviz and ensure dot is in PATH."
        )
    subprocess.run([dot_bin, "-Tpng", str(dot_path), "-o", str(png_path)], check=True)
    subprocess.run([dot_bin, "-Tsvg", str(dot_path), "-o", str(svg_path)], check=True)


def write_report(report_path: Path, input_path: Path, nodes, edges, dot_path, png_path, svg_path):
    type_counts = {}
    for t in nodes.values():
        type_counts[t] = type_counts.get(t, 0) + 1

    report_path.write_text(
        "Stable CRG Graphviz generator report\n"
        f"Input: {input_path}\n"
        f"Nodes: {len(nodes)}\n"
        f"Edges: {len(edges)}\n"
        f"Types: {dict(sorted(type_counts.items()))}\n"
        f"DOT: {dot_path}\n"
        f"PNG: {png_path}\n"
        f"SVG: {svg_path}\n",
        encoding="utf-8",
    )


def main():
    ap = argparse.ArgumentParser(description="Generate stable CRG Graphviz diagrams from Excel.")
    ap.add_argument("-i", "--input", required=True, help="Input Excel file (.xlsx)")
    ap.add_argument("-o", "--outdir", default="outputs", help="Output directory")
    ap.add_argument("-b", "--basename", default=None, help="Output base name")
    ap.add_argument("--sheet", default=None, help="Worksheet name. Default: first sheet")
    ap.add_argument("--title", default="CRG Logic Diagram - Stable Graphviz")
    ap.add_argument("--nodesep", type=float, default=0.55, help="Graphviz nodesep. Smaller is more compact.")
    ap.add_argument("--ranksep", type=float, default=1.05, help="Graphviz ranksep. Smaller is more compact.")
    ap.add_argument("--compact", action="store_true", help="Use compact spacing preset.")
    ap.add_argument("--sink-constraint", action="store_true", help="Let SINK edges affect layout more strongly.")
    ap.add_argument("--no-render", action="store_true", help="Only output DOT, do not render PNG/SVG.")
    args = ap.parse_args()

    input_path = Path(args.input)
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    basename = args.basename or input_path.stem

    nodesep = args.nodesep
    ranksep = args.ranksep
    if args.compact:
        nodesep = 0.42
        ranksep = 0.82

    nodes, edges, row_order = parse_excel(input_path, sheet_name=args.sheet)
    dot_text = generate_dot(
        nodes=nodes,
        edges=edges,
        row_order=row_order,
        title=args.title,
        nodesep=nodesep,
        ranksep=ranksep,
        sink_constraint=args.sink_constraint,
    )

    dot_path = outdir / f"{basename}.dot"
    png_path = outdir / f"{basename}.png"
    svg_path = outdir / f"{basename}.svg"
    report_path = outdir / f"{basename}_report.txt"

    dot_path.write_text(dot_text, encoding="utf-8")

    if not args.no_render:
        render_graphviz(dot_path, png_path, svg_path)

    write_report(
        report_path,
        input_path,
        nodes,
        edges,
        dot_path,
        png_path if not args.no_render else "not rendered",
        svg_path if not args.no_render else "not rendered",
    )

    print(report_path.read_text(encoding="utf-8"))


if __name__ == "__main__":
    main()
