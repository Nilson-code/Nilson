Write-Host "Running CRG Graphviz Stable Skill example..."
python .\crg_stable_graphviz_generator.py -i .\examples\component_example_logic_revised.xlsx -o .\outputs -b demo --compact
Write-Host "Done. Check outputs/demo.png and outputs/demo.svg"
