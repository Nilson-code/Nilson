---
name: crg_graphviz_stable
description: Generate stable SRC-left / SINK-right Graphviz CRG logic diagrams from Excel connectivity tables.
---

# CRG Graphviz Stable Skill

Use this skill when the user has an Excel connectivity table and wants a stable CRG / clock-reset / logic diagram.

## Input Excel Columns

The default schema is:

```text
NAME | TYPE | IN1 | IN2 | IN3 | IN4 | OUT1 | OUT2 | OUT3 | OUT4 | NOTE
```

`IN*` columns create edges from input signal/component to `NAME`.

`OUT*` columns create edges from `NAME` to output signal/component.

## Supported TYPE Values

```text
SRC, SINK, BUF, PLL, DIV, SYNC, CG, OCC, MUX, AND, OR, INV, LOGIC, WIRE
```

Aliases are normalized, for example `CLK_GATE -> CG`, `RST_SYNC -> SYNC`, `SOURCE -> SRC`, `OUTPUT -> SINK`.

## Stable Layout Rules

This skill uses the stable style selected by the user:

1. `SRC` cluster is locked to the left using `rank=source`.
2. `SINK` cluster is locked to the right using `rank=sink`.
3. Intermediate logic is not over-constrained; Graphviz is allowed to place it naturally.
4. Only one invisible guide chain stabilizes the main clock path.
5. `SRC` and `SINK` vertical order follows the Excel row order.
6. Reset edges are red dashed.
7. Enable/control edges are green dotted.
8. Clock/data edges are gray solid.
9. Edges into `SINK` default to `constraint=false` to avoid output fanout distorting the middle logic.

## Command

```bash
python crg_stable_graphviz_generator.py \
  --input examples/component_example_logic_revised.xlsx \
  --outdir outputs \
  --basename demo \
  --compact
```

## Outputs

```text
outputs/demo.dot
outputs/demo.png
outputs/demo.svg
outputs/demo_report.txt
```

## Required Local Dependencies

- Python 3.9+
- `openpyxl`
- Graphviz system binary `dot`

Install Python dependency:

```bash
pip install -r requirements.txt
```

Check Graphviz:

```bash
dot -V
```

## Recommended Default

Use:

```bash
python crg_stable_graphviz_generator.py -i your_logic.xlsx -o outputs -b result --compact
```

If the diagram becomes too dense, remove `--compact`.
