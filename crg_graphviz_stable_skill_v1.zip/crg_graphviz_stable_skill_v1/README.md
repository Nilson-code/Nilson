# CRG Graphviz Stable Skill v1

这是一个离线可复用的 CRG/时钟复位逻辑图生成 skill。

它固定采用现在效果比较稳定的思路：

```text
SRC 固定左侧
SINK 固定右侧
中间逻辑由 Graphviz 自动排
不强行每一级 rank
不默认 fanout junction
```

## 1. 安装依赖

### 1.1 安装 Python 包

在这个目录打开终端：

```bash
pip install -r requirements.txt
```

### 1.2 安装 Graphviz

需要系统命令里能找到 `dot`：

```bash
dot -V
```

如果 Windows 提示找不到 `dot`，说明 Graphviz 没加到 PATH。把 Graphviz 的 `bin` 目录加入系统 PATH 后重开终端。

## 2. Excel 输入格式

默认列结构：

```text
NAME | TYPE | IN1 | IN2 | IN3 | IN4 | OUT1 | OUT2 | OUT3 | OUT4 | NOTE
```

例子：

```text
u_buf | BUF | clk_in | | | | div2
div2  | DIV | u_buf  | rst_n | | | clk_out | cg1
```

## 3. 运行示例

Windows CMD：

```bat
python crg_stable_graphviz_generator.py -i examples\component_example_logic_revised.xlsx -o outputs -b demo --compact
```

PowerShell：

```powershell
python .\crg_stable_graphviz_generator.py -i .\examples\component_example_logic_revised.xlsx -o .\outputs -b demo --compact
```

Linux/macOS：

```bash
python crg_stable_graphviz_generator.py -i examples/component_example_logic_revised.xlsx -o outputs -b demo --compact
```

## 4. 输出文件

```text
outputs/demo.dot
outputs/demo.png
outputs/demo.svg
outputs/demo_report.txt
```

## 5. 常用参数

### 普通模式

```bash
python crg_stable_graphviz_generator.py -i your.xlsx -o outputs -b result
```

### 紧凑模式

```bash
python crg_stable_graphviz_generator.py -i your.xlsx -o outputs -b result --compact
```

### 只生成 DOT，不渲染图片

```bash
python crg_stable_graphviz_generator.py -i your.xlsx -o outputs -b result --no-render
```

### 指定 sheet

```bash
python crg_stable_graphviz_generator.py -i your.xlsx --sheet Sheet1 -o outputs -b result
```

## 6. 设计规则

这个版本刻意避免之前那些会导致图变乱的做法：

```text
不强行每一级 rank
不把所有 fanout 都变成 junction
不让 SINK 输出反向拉乱中间逻辑
```

核心稳定约束是：

```text
SRC rank=source
SINK rank=sink
主时钟链 invisible guide
```

## 7. 后续可扩展

后面如果要加“手动 draw.io 布局 + Graphviz 自动布线”，建议另开一个脚本，不要污染这个默认稳定版本。
