# CRG Graphviz Logic Renderer

This package turns an Excel CRG logic table into deterministic Graphviz diagrams.

## Excel schema

The renderer expects a table like:

```text
NAME | TYPE | IN1 | IN2 | IN3 | IN4 | OUT1 | OUT2 | OUT3 | OUT4 | NOTE
```

Parsing logic:

- `IN*` cells generate `input -> NAME`
- `OUT*` cells generate `NAME -> output`
- edges are deduplicated
- referenced but undefined nodes are rendered as `SIGNAL`

## Quick start

Install dependencies:

```bash
pip install -r requirements.txt
```

Install Graphviz so both `dot` and `neato` are available in your PATH. The default optimized layout renders with `neato -n2`; the clustered fallback uses `dot`.

Render:

```bash
python render_crg.py \
  --input examples/crg_logic_template.xlsx \
  --sheet Logic \
  --outdir out \
  --name crg_logic \
  --title "CRG Logic Map" \
  --style config/crg_style.json \
  --formats png,svg,pdf \
  --layout optimized
```

Outputs:

```text
out/crg_logic.dot
out/crg_logic.png
out/crg_logic.svg
out/crg_logic.pdf
```

## Design choices

The skill follows the common Graphviz pattern of separating **data structure** from **visual style**:

1. Excel stores nodes and relationships.
2. Python normalizes the table into nodes and edges.
3. DOT encodes hierarchy, clusters, ranks, colors, shapes, and edge routing.
4. Graphviz renders stable SVG/PNG/PDF.

## Stability rules

For repeatable output:

- keep `NAME` unique
- keep row order intentional
- avoid mixing unrelated blocks in one sheet
- prefer concise signal names
- use `TYPE` consistently
- change colors through `config/crg_style.json`, not by editing generated DOT manually



The optimized mode includes a stable CRG skeleton: when the core CRG backbone is recognized, optional rows may disappear without causing global re-layout. This is the recommended mode for comparing different versions of the same CRG block.

## Layout modes

- `--layout optimized` default: fixed-lane CRG layout, stable coordinates, fewer crossings, and dashed visual taps for outputs reused internally.
- `--layout clustered`: automatic Graphviz cluster layout, useful for quick exploratory diagrams or unfamiliar logic blocks.

For CRG review documents, prefer SVG from the optimized layout. PNG is intended for quick chat previews.
