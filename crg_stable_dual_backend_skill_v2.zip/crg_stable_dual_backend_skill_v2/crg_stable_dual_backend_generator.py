#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations

import argparse
import math
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Tuple, Iterable, Optional

from openpyxl import load_workbook

try:
    from PIL import Image, ImageDraw, ImageFont
    PIL_AVAILABLE = True
except Exception:
    PIL_AVAILABLE = False


TYPE_COLOR = {
    "SRC":   ("#2F75B5", "#BFE3FF"),
    "SINK":  ("#548235", "#E2F0D9"),
    "BUF":   ("#BF9000", "#FFF2CC"),
    "PLL":   ("#548235", "#E2F0D9"),
    "DIV":   ("#C65911", "#FCE4D6"),
    "SYNC":  ("#7030A0", "#E4DFEC"),
    "CG":    ("#5B9BD5", "#DDEBF7"),
    "OCC":   ("#5B9BD5", "#DDEBF7"),
    "MUX":   ("#BF9000", "#FFF2CC"),
    "AND":   ("#BF9000", "#FFF2CC"),
    "OR":    ("#C00000", "#F8CBAD"),
    "INV":   ("#7F6000", "#FFF2CC"),
    "WIRE":  ("#7F7F7F", "#E7E6E6"),
    "LOGIC": ("#7F6000", "#FFF2CC"),
}

TYPE_PRIORITY = {
    "BUF": 1,
    "PLL": 2,
    "DIV": 3,
    "MUX": 4,
    "AND": 4,
    "OR": 4,
    "INV": 4,
    "SYNC": 5,
    "CG": 6,
    "OCC": 6,
    "LOGIC": 7,
    "WIRE": 8,
}


def q(name: str) -> str:
    return '"' + str(name).replace("\\", "\\\\").replace('"', '\\"') + '"'


def xml_escape(s: str) -> str:
    return (
        str(s)
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
    )


def norm_type(t: Optional[str]) -> str:
    if not t:
        return "LOGIC"
    s = str(t).strip().upper()
    aliases = {
        "CLOCK_GATE": "CG",
        "CLK_GATE": "CG",
        "GATE": "CG",
        "CLKGATE": "CG",
        "RESET_SYNC": "SYNC",
        "RST_SYNC": "SYNC",
        "SYNCHRONIZER": "SYNC",
        "SOURCE": "SRC",
        "OUTPUT": "SINK",
        "OUT": "SINK",
        "CLOCK_OUT": "SINK",
        "CLK_OUT": "SINK",
        "COMB": "LOGIC",
    }
    return aliases.get(s, s)


def is_reset_name(n: str) -> bool:
    s = n.lower()
    return "rst" in s or "reset" in s


def is_enable_name(n: str) -> bool:
    s = n.lower()
    return (
        "clk_en" in s
        or s.endswith("_en")
        or "_en_" in s
        or "enable" in s
        or "scan_en" in s
    )


def is_clockish_name(n: str) -> bool:
    s = n.lower()
    return any(k in s for k in ["clk", "clock", "cg", "div", "pll", "aon", "gate"])


def clean_cell(v) -> Optional[str]:
    if v is None:
        return None
    s = str(v).strip()
    return s if s else None


def parse_excel(xlsx_path: Path, sheet_name: Optional[str] = None):
    wb = load_workbook(xlsx_path, data_only=True)
    ws = wb[sheet_name] if sheet_name else wb[wb.sheetnames[0]]
    rows = list(ws.iter_rows(values_only=True))

    header_idx = None
    headers = None
    for i, row in enumerate(rows):
        row_upper = [str(x).strip().upper() if x is not None else "" for x in row]
        if "NAME" in row_upper and "TYPE" in row_upper:
            header_idx = i
            headers = row_upper
            break

    if header_idx is None or headers is None:
        raise ValueError("Excel must contain NAME and TYPE columns.")

    col = {h: idx for idx, h in enumerate(headers) if h}

    def cell(row, key):
        idx = col.get(key)
        if idx is None or idx >= len(row):
            return None
        return clean_cell(row[idx])

    nodes: Dict[str, str] = {}
    row_order: Dict[str, int] = {}
    data_rows = []

    for r_i, row in enumerate(rows[header_idx + 1 :], start=header_idx + 2):
        name = cell(row, "NAME")
        typ = cell(row, "TYPE")
        if not name:
            continue
        nodes[name] = norm_type(typ)
        row_order[name] = r_i
        data_rows.append(row)

    in_cols = sorted([h for h in headers if re.fullmatch(r"IN\d+", h)], key=lambda x: int(x[2:]))
    out_cols = sorted([h for h in headers if re.fullmatch(r"OUT\d+", h)], key=lambda x: int(x[3:]))

    edges: List[Tuple[str, str]] = []
    edge_set = set()

    def add_edge(a, b):
        if a and b and a != b and (a, b) not in edge_set:
            edge_set.add((a, b))
            edges.append((a, b))

    for row in data_rows:
        name = cell(row, "NAME")
        if not name:
            continue
        for c in in_cols:
            src = cell(row, c)
            if src:
                nodes.setdefault(src, "WIRE")
                row_order.setdefault(src, 9999 + len(row_order))
                add_edge(src, name)
        for c in out_cols:
            dst = cell(row, c)
            if dst:
                nodes.setdefault(dst, "SINK")
                row_order.setdefault(dst, 9999 + len(row_order))
                add_edge(name, dst)

    succ = build_succ(edges)
    for n in list(nodes):
        if nodes[n] == "WIRE" and not succ.get(n):
            nodes[n] = "SINK"

    return nodes, edges, row_order


def build_succ(edges: Iterable[Tuple[str, str]]) -> Dict[str, List[str]]:
    succ: Dict[str, List[str]] = {}
    for a, b in edges:
        succ.setdefault(a, []).append(b)
    return succ


def build_pred(edges: Iterable[Tuple[str, str]]) -> Dict[str, List[str]]:
    pred: Dict[str, List[str]] = {}
    for a, b in edges:
        pred.setdefault(b, []).append(a)
    return pred


def is_output_buffer(n: str, nodes: Dict[str, str], succ: Dict[str, List[str]]) -> bool:
    return nodes.get(n) == "BUF" and any(nodes.get(v) == "SINK" for v in succ.get(n, []))


def is_post_div_buf(n: str, nodes: Dict[str, str], pred: Dict[str, List[str]]) -> bool:
    return nodes.get(n) == "BUF" and any(nodes.get(p) == "DIV" or "div" in p.lower() for p in pred.get(n, []))


def semantic_rank(n: str, nodes: Dict[str, str], edges: List[Tuple[str, str]]) -> int:
    succ = build_succ(edges)
    pred = build_pred(edges)
    typ = nodes.get(n, "LOGIC")

    if typ == "SRC":
        return 0
    if typ == "SINK":
        return 7
    if is_output_buffer(n, nodes, succ):
        return 6
    if typ == "BUF":
        if is_post_div_buf(n, nodes, pred):
            return 3
        return 1
    if typ == "PLL":
        return 1
    if typ in {"AND", "OR", "INV"}:
        return 1
    if typ in {"DIV", "MUX"}:
        return 2
    if typ == "SYNC":
        if any(nodes.get(p) in {"MUX", "AND", "OR", "INV"} for p in pred.get(n, [])):
            return 3
        return 4
    if typ in {"CG", "OCC"}:
        return 5
    return 3


def node_sort_key(n: str, nodes: Dict[str, str], row_order: Dict[str, int]):
    typ = nodes.get(n, "LOGIC")
    if typ == "SRC":
        return (
            0 if is_clockish_name(n) and not is_reset_name(n) else 1 if is_reset_name(n) else 2,
            row_order.get(n, 99999),
            n,
        )
    if typ == "SINK":
        return (
            0 if is_clockish_name(n) and not is_reset_name(n) else 1 if is_reset_name(n) else 2,
            row_order.get(n, 99999),
            n,
        )
    return (
        1 if is_reset_name(n) else 0,
        TYPE_PRIORITY.get(typ, 99),
        row_order.get(n, 99999),
        n,
    )


def estimate_node_size(name: str):
    w = max(118, min(210, 9 * len(name) + 44))
    h = 46
    return w, h


def build_python_layout(nodes, edges, row_order, compact=False):
    rank_groups: Dict[int, List[str]] = {}
    for n in nodes:
        r = semantic_rank(n, nodes, edges)
        rank_groups.setdefault(r, []).append(n)

    for r in rank_groups:
        rank_groups[r].sort(key=lambda n: node_sort_key(n, nodes, row_order))

    x_gap = 155 if compact else 185
    y_gap = 62 if compact else 76
    margin_x = 70
    margin_y = 88
    title_h = 48

    max_count = max((len(v) for v in rank_groups.values()), default=1)
    positions = {}
    sizes = {}

    for r in range(0, 8):
        group = rank_groups.get(r, [])
        col_h = (len(group) - 1) * y_gap
        center_offset = (max_count - 1) * y_gap / 2.0
        start_y = margin_y + title_h + center_offset - col_h / 2.0
        for i, n in enumerate(group):
            w, h = estimate_node_size(n)
            x = margin_x + r * x_gap
            y = start_y + i * y_gap
            positions[n] = (x, y)
            sizes[n] = (w, h)

    max_x = max((positions[n][0] + sizes[n][0] for n in positions), default=1000)
    max_y = max((positions[n][1] + sizes[n][1] for n in positions), default=800)
    width = int(max_x + margin_x)
    height = int(max_y + margin_y)
    return positions, sizes, width, height, rank_groups


def edge_color_and_style(a: str, b: str):
    if is_enable_name(a) or is_enable_name(b):
        return "#6AA84F", "dotted"
    if is_reset_name(a) or is_reset_name(b):
        return "#B85450", "dashed"
    return "#666666", "solid"


def orthogonal_path(a: str, b: str, positions, sizes):
    ax, ay = positions[a]
    aw, ah = sizes[a]
    bx, by = positions[b]
    bw, bh = sizes[b]
    start = (ax + aw, ay + ah / 2)
    end = (bx, by + bh / 2)
    if end[0] <= start[0] + 18:
        mid_x = start[0] + 28
    else:
        mid_x = (start[0] + end[0]) / 2
    return [start, (mid_x, start[1]), (mid_x, end[1]), end]


def svg_polyline(points, color, style):
    pts = " ".join(f"{x:.1f},{y:.1f}" for x, y in points)
    dash = ""
    if style == "dashed":
        dash = ' stroke-dasharray="7,5"'
    elif style == "dotted":
        dash = ' stroke-dasharray="2,5"'
    return f'<polyline points="{pts}" fill="none" stroke="{color}" stroke-width="1.35"{dash} marker-end="url(#arrow)"/>'


def svg_node(n, typ, x, y, w, h):
    stroke, fill = TYPE_COLOR.get(typ, TYPE_COLOR["LOGIC"])
    label1 = xml_escape(n)
    label2 = xml_escape(f"<{typ}>")
    return f"""
  <g>
    <rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" rx="8" ry="8" fill="{fill}" stroke="{stroke}" stroke-width="1.2"/>
    <text x="{x+w/2:.1f}" y="{y+19:.1f}" text-anchor="middle" font-family="Arial" font-size="11" fill="#1F1F1F">{label1}</text>
    <text x="{x+w/2:.1f}" y="{y+35:.1f}" text-anchor="middle" font-family="Arial" font-size="10" fill="#444444">{label2}</text>
  </g>"""


def render_python_svg(nodes, edges, row_order, svg_path: Path, title: str, compact=False):
    positions, sizes, width, height, rank_groups = build_python_layout(nodes, edges, row_order, compact=compact)

    parts = []
    parts.append(f"""<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">
  <defs>
    <marker id="arrow" markerWidth="9" markerHeight="7" refX="8" refY="3.5" orient="auto" markerUnits="strokeWidth">
      <path d="M0,0 L9,3.5 L0,7 z" fill="#666666"/>
    </marker>
  </defs>
  <rect x="0" y="0" width="{width}" height="{height}" fill="white"/>
  <text x="{width/2:.1f}" y="30" text-anchor="middle" font-family="Arial" font-size="21" font-weight="600" fill="#222222">{xml_escape(title)}</text>
""")

    # Cluster boxes
    for rank, label in [(0, "SRC"), (7, "SINK")]:
        group = rank_groups.get(rank, [])
        if not group:
            continue
        xs = [positions[n][0] for n in group]
        ys = [positions[n][1] for n in group]
        ws = [sizes[n][0] for n in group]
        hs = [sizes[n][1] for n in group]
        x0, y0 = min(xs)-16, min(ys)-34
        x1, y1 = max(x+w for x,w in zip(xs,ws))+16, max(y+h for y,h in zip(ys,hs))+16
        parts.append(f'<rect x="{x0:.1f}" y="{y0:.1f}" width="{x1-x0:.1f}" height="{y1-y0:.1f}" rx="10" fill="none" stroke="#D9D9D9" stroke-dasharray="6,5"/>')
        parts.append(f'<text x="{(x0+x1)/2:.1f}" y="{y0+20:.1f}" text-anchor="middle" font-family="Arial" font-size="12" fill="#666666">{label}</text>')

    for a, b in edges:
        if a not in positions or b not in positions:
            continue
        color, style = edge_color_and_style(a, b)
        pts = orthogonal_path(a, b, positions, sizes)
        parts.append("  " + svg_polyline(pts, color, style))

    for n in sorted(nodes, key=lambda name: (positions[name][0], positions[name][1])):
        x, y = positions[n]
        w, h = sizes[n]
        parts.append(svg_node(n, nodes.get(n, "LOGIC"), x, y, w, h))

    parts.append("</svg>\n")
    svg_path.write_text("\n".join(parts), encoding="utf-8")


def draw_dashed_line(draw, points, fill, width=2, dash=(8, 6)):
    for (x1, y1), (x2, y2) in zip(points[:-1], points[1:]):
        dx = x2 - x1
        dy = y2 - y1
        dist = math.hypot(dx, dy)
        if dist == 0:
            continue
        ux, uy = dx / dist, dy / dist
        pos = 0
        while pos < dist:
            seg_end = min(pos + dash[0], dist)
            draw.line((x1 + ux * pos, y1 + uy * pos, x1 + ux * seg_end, y1 + uy * seg_end), fill=fill, width=width)
            pos += dash[0] + dash[1]


def draw_arrow(draw, p1, p2, fill):
    x1, y1 = p1
    x2, y2 = p2
    ang = math.atan2(y2 - y1, x2 - x1)
    length = 9
    spread = 0.45
    pA = (x2, y2)
    pB = (x2 - length * math.cos(ang - spread), y2 - length * math.sin(ang - spread))
    pC = (x2 - length * math.cos(ang + spread), y2 - length * math.sin(ang + spread))
    draw.polygon([pA, pB, pC], fill=fill)


def render_python_png(nodes, edges, row_order, png_path: Path, title: str, compact=False):
    if not PIL_AVAILABLE:
        raise RuntimeError("Pillow is not installed. Install with: pip install pillow")

    positions, sizes, width, height, rank_groups = build_python_layout(nodes, edges, row_order, compact=compact)

    img = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(img)

    try:
        font_title = ImageFont.truetype("arial.ttf", 22)
        font_node = ImageFont.truetype("arial.ttf", 11)
        font_type = ImageFont.truetype("arial.ttf", 10)
        font_cluster = ImageFont.truetype("arial.ttf", 12)
    except Exception:
        try:
            font_title = ImageFont.truetype("DejaVuSans.ttf", 22)
            font_node = ImageFont.truetype("DejaVuSans.ttf", 11)
            font_type = ImageFont.truetype("DejaVuSans.ttf", 10)
            font_cluster = ImageFont.truetype("DejaVuSans.ttf", 12)
        except Exception:
            font_title = ImageFont.load_default()
            font_node = ImageFont.load_default()
            font_type = ImageFont.load_default()
            font_cluster = ImageFont.load_default()

    bbox = draw.textbbox((0, 0), title, font=font_title)
    draw.text(((width - (bbox[2]-bbox[0])) / 2, 12), title, fill="#222222", font=font_title)

    for rank, label in [(0, "SRC"), (7, "SINK")]:
        group = rank_groups.get(rank, [])
        if not group:
            continue
        xs = [positions[n][0] for n in group]
        ys = [positions[n][1] for n in group]
        ws = [sizes[n][0] for n in group]
        hs = [sizes[n][1] for n in group]
        x0, y0 = min(xs)-16, min(ys)-34
        x1, y1 = max(x+w for x,w in zip(xs,ws))+16, max(y+h for y,h in zip(ys,hs))+16
        draw.rectangle((x0, y0, x1, y1), outline="#D9D9D9", width=1)
        lb = draw.textbbox((0, 0), label, font=font_cluster)
        draw.text(((x0+x1-(lb[2]-lb[0]))/2, y0+5), label, fill="#666666", font=font_cluster)

    for a, b in edges:
        if a not in positions or b not in positions:
            continue
        color, style = edge_color_and_style(a, b)
        pts = orthogonal_path(a, b, positions, sizes)
        if style == "solid":
            draw.line(pts, fill=color, width=2)
        elif style == "dashed":
            draw_dashed_line(draw, pts, fill=color, width=2, dash=(8, 6))
        else:
            draw_dashed_line(draw, pts, fill=color, width=2, dash=(2, 6))
        draw_arrow(draw, pts[-2], pts[-1], color)

    for n in sorted(nodes, key=lambda name: (positions[name][0], positions[name][1])):
        typ = nodes.get(n, "LOGIC")
        stroke, fill = TYPE_COLOR.get(typ, TYPE_COLOR["LOGIC"])
        x, y = positions[n]
        w, h = sizes[n]
        draw.rounded_rectangle((x, y, x+w, y+h), radius=8, fill=fill, outline=stroke, width=2)

        text1 = n
        text2 = f"<{typ}>"
        bb1 = draw.textbbox((0,0), text1, font=font_node)
        bb2 = draw.textbbox((0,0), text2, font=font_type)
        draw.text((x + (w-(bb1[2]-bb1[0]))/2, y + 7), text1, fill="#1F1F1F", font=font_node)
        draw.text((x + (w-(bb2[2]-bb2[0]))/2, y + 25), text2, fill="#444444", font=font_type)

    img.save(png_path)


# DOT debug / optional Graphviz backend

def choose_main_backbone(nodes, edges, row_order):
    succ = build_succ(edges)
    starts = [n for n, t in nodes.items() if t == "SRC" and is_clockish_name(n) and not is_reset_name(n)]
    if not starts:
        starts = [n for n, t in nodes.items() if t == "SRC"]

    def next_score(v):
        typ = nodes.get(v, "LOGIC")
        return (
            0 if typ in {"BUF", "PLL"} else
            1 if typ == "DIV" else
            2 if typ == "SYNC" else
            3 if typ in {"CG", "OCC"} else
            4 if typ == "SINK" and is_clockish_name(v) else
            9,
            row_order.get(v, 99999),
            v,
        )

    best_chain = []
    for st in sorted(starts, key=lambda n: row_order.get(n, 99999)):
        chain = [st]
        cur = st
        seen = {cur}
        for _ in range(30):
            candidates = [v for v in succ.get(cur, []) if v not in seen and not is_reset_name(v)]
            candidates.sort(key=next_score)
            if not candidates:
                break
            nxt = candidates[0]
            chain.append(nxt)
            seen.add(nxt)
            cur = nxt
            if nodes.get(cur) == "SINK":
                break
        if len(chain) > len(best_chain):
            best_chain = chain
    return [n for n in best_chain if nodes.get(n) != "SINK"]


def sort_src(nodes, row_order):
    return sorted(
        [n for n, t in nodes.items() if t == "SRC"],
        key=lambda n: (
            0 if is_clockish_name(n) and not is_reset_name(n) else 1 if is_reset_name(n) else 2,
            row_order.get(n, 99999),
            n,
        ),
    )


def sort_sink(nodes, row_order):
    return sorted(
        [n for n, t in nodes.items() if t == "SINK"],
        key=lambda n: (
            0 if is_clockish_name(n) and not is_reset_name(n) else 1 if is_reset_name(n) else 2,
            row_order.get(n, 99999),
            n,
        ),
    )


def sort_middle(nodes, row_order):
    return sorted(
        [n for n, t in nodes.items() if t not in {"SRC", "SINK"}],
        key=lambda n: (
            1 if is_reset_name(n) else 0,
            TYPE_PRIORITY.get(nodes.get(n, "LOGIC"), 99),
            row_order.get(n, 99999),
            n,
        ),
    )


def dot_edge_style(a, b, nodes):
    attrs = []
    if is_enable_name(a) or is_enable_name(b):
        attrs += ['color="#6AA84F"', 'style="dotted"', "penwidth=1.2"]
    elif is_reset_name(a) or is_reset_name(b):
        attrs += ['color="#B85450"', 'style="dashed"', "penwidth=1.2"]
    else:
        attrs += ['color="#666666"', "penwidth=1.25"]
    if nodes.get(b) == "SINK":
        attrs += ["constraint=false", "weight=1"]
    return "[" + ", ".join(attrs) + "]"


def generate_dot(nodes, edges, row_order, title, compact=False):
    nodesep = 0.42 if compact else 0.55
    ranksep = 0.82 if compact else 1.05
    src_nodes = sort_src(nodes, row_order)
    sink_nodes = sort_sink(nodes, row_order)
    mid_nodes = sort_middle(nodes, row_order)
    main_backbone = choose_main_backbone(nodes, edges, row_order)

    lines = []
    lines.append("digraph G {")
    lines.append(f'  graph [rankdir=LR, splines=ortho, nodesep={nodesep:.2f}, ranksep={ranksep:.2f}, pad=0.18, margin=0.04, overlap=false, bgcolor=white, labelloc=t, label="{title}", fontsize=22, fontname="Arial", newrank=true, ordering=out];')
    lines.append('  node [shape=box, style="rounded,filled", fontname="Arial", fontsize=11, margin="0.08,0.05", penwidth=1.15];')
    lines.append('  edge [arrowsize=0.7, fontname="Arial", fontsize=8];')

    lines.append('  subgraph cluster_src {')
    lines.append('    label="SRC"; style="rounded,dashed"; color="#D9D9D9";')
    lines.append('    rank=source;')
    for n in src_nodes:
        stroke, fill = TYPE_COLOR.get(nodes[n], TYPE_COLOR["LOGIC"])
        lines.append(f'    {q(n)} [label="{n}\\n<{nodes[n]}>", fillcolor="{fill}", color="{stroke}"];')
    lines.append('  }')

    for n in mid_nodes:
        typ = nodes.get(n, "LOGIC")
        stroke, fill = TYPE_COLOR.get(typ, TYPE_COLOR["LOGIC"])
        lines.append(f'  {q(n)} [label="{n}\\n<{typ}>", fillcolor="{fill}", color="{stroke}"];')

    lines.append('  subgraph cluster_sink {')
    lines.append('    label="SINK"; style="rounded,dashed"; color="#D9D9D9";')
    lines.append('    rank=sink;')
    for n in sink_nodes:
        stroke, fill = TYPE_COLOR.get(nodes[n], TYPE_COLOR["SINK"])
        lines.append(f'    {q(n)} [label="{n}\\n<{nodes[n]}>", fillcolor="{fill}", color="{stroke}"];')
    lines.append('  }')

    for group in [src_nodes, sink_nodes]:
        for a, b in zip(group[:-1], group[1:]):
            lines.append(f"  {q(a)} -> {q(b)} [style=invis, weight=80, constraint=false];")

    for a, b in zip(main_backbone[:-1], main_backbone[1:]):
        lines.append(f"  {q(a)} -> {q(b)} [style=invis, weight=25];")

    if src_nodes and sink_nodes:
        guide = [src_nodes[0]]
        for n in main_backbone:
            if n not in guide and nodes.get(n) not in {"SRC", "SINK"}:
                guide.append(n)
        guide.append(sink_nodes[0])
        for a, b in zip(guide[:-1], guide[1:]):
            lines.append(f"  {q(a)} -> {q(b)} [style=invis, weight=120, minlen=1];")

    for a, b in edges:
        lines.append(f"  {q(a)} -> {q(b)} {dot_edge_style(a, b, nodes)};")

    lines.append("}")
    return "\n".join(lines)


def render_graphviz(dot_path, png_path, svg_path):
    dot_bin = shutil.which("dot")
    if not dot_bin:
        raise RuntimeError("Graphviz dot executable not found")
    subprocess.run([dot_bin, "-Tpng", str(dot_path), "-o", str(png_path)], check=True)
    subprocess.run([dot_bin, "-Tsvg", str(dot_path), "-o", str(svg_path)], check=True)


def write_report(report_path, input_path, nodes, edges, backend, dot_path, png_path, svg_path):
    type_counts = {}
    for t in nodes.values():
        type_counts[t] = type_counts.get(t, 0) + 1
    report_path.write_text(
        "CRG Stable Dual Backend generator report\n"
        f"Input: {input_path}\n"
        f"Backend used: {backend}\n"
        f"Nodes: {len(nodes)}\n"
        f"Edges: {len(edges)}\n"
        f"Types: {dict(sorted(type_counts.items()))}\n"
        f"DOT: {dot_path if dot_path else 'not generated'}\n"
        f"PNG: {png_path if png_path else 'not generated'}\n"
        f"SVG: {svg_path if svg_path else 'not generated'}\n",
        encoding="utf-8",
    )


def main():
    ap = argparse.ArgumentParser(description="Generate stable CRG diagrams from Excel. Graphviz optional.")
    ap.add_argument("-i", "--input", required=True, help="Input Excel file")
    ap.add_argument("-o", "--outdir", default="outputs", help="Output directory")
    ap.add_argument("-b", "--basename", default=None, help="Output basename")
    ap.add_argument("--sheet", default=None, help="Worksheet name")
    ap.add_argument("--title", default="CRG Logic Diagram - Stable Dual Backend")
    ap.add_argument("--backend", choices=["auto", "graphviz", "python"], default="auto")
    ap.add_argument("--compact", action="store_true")
    ap.add_argument("--no-png", action="store_true")
    ap.add_argument("--no-svg", action="store_true")
    args = ap.parse_args()

    input_path = Path(args.input)
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    basename = args.basename or input_path.stem

    nodes, edges, row_order = parse_excel(input_path, args.sheet)

    dot_path = outdir / f"{basename}.dot"
    png_path = outdir / f"{basename}.png"
    svg_path = outdir / f"{basename}.svg"
    report_path = outdir / f"{basename}_report.txt"

    selected = args.backend
    if selected == "auto":
        selected = "graphviz" if shutil.which("dot") else "python"

    backend_used = selected
    if selected == "graphviz" and not shutil.which("dot"):
        print("[warn] Graphviz dot not found; fallback to python backend.", file=sys.stderr)
        selected = "python"
        backend_used = "python-fallback"

    dot_path.write_text(generate_dot(nodes, edges, row_order, args.title, compact=args.compact), encoding="utf-8")

    if selected == "graphviz":
        render_graphviz(dot_path, png_path, svg_path)
        if args.no_png and png_path.exists():
            png_path.unlink()
            png_path = None
        if args.no_svg and svg_path.exists():
            svg_path.unlink()
            svg_path = None
    else:
        if args.no_svg:
            svg_path = None
        else:
            render_python_svg(nodes, edges, row_order, svg_path, args.title, compact=args.compact)

        if args.no_png:
            png_path = None
        else:
            render_python_png(nodes, edges, row_order, png_path, args.title, compact=args.compact)

    write_report(report_path, input_path, nodes, edges, backend_used, dot_path, png_path, svg_path)
    print(report_path.read_text(encoding="utf-8"))


if __name__ == "__main__":
    main()
