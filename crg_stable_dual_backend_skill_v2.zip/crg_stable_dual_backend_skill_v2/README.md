# CRG Stable Dual Backend Skill v2

这个版本不把 Graphviz 作为硬依赖。

## 最推荐用法：不装 Graphviz

```bash
pip install -r requirements.txt
python crg_stable_dual_backend_generator.py -i examples/component_example_logic_revised.xlsx -o outputs -b demo_python --backend python --compact
```

Windows 可以直接双击：

```text
run_example_python.bat
```

## 自动后端

```bash
python crg_stable_dual_backend_generator.py -i your_logic.xlsx -o outputs -b result --backend auto --compact
```

逻辑：

```text
有 dot -> Graphviz
没有 dot -> pure Python
```

## 输出文件

```text
outputs/result.dot
outputs/result.svg
outputs/result.png
outputs/result_report.txt
```

注意：pure Python 后端也会输出 DOT，但 DOT 只是调试/兼容用，图片不是靠 Graphviz 渲染的。

## Excel 格式

```text
NAME | TYPE | IN1 | IN2 | IN3 | IN4 | OUT1 | OUT2 | OUT3 | OUT4 | NOTE
```

支持 TYPE：

```text
SRC, SINK, BUF, PLL, DIV, SYNC, CG, OCC, MUX, AND, OR, INV, LOGIC, WIRE
```

## 设计规则

```text
SRC 左侧
SINK 右侧
中间按语义列稳定摆放
reset 红色虚线
enable 绿色点线
clock/data 灰色实线
```
