@echo off
setlocal
echo Running pure Python backend. Graphviz is NOT required.
python crg_stable_dual_backend_generator.py -i examples\component_example_logic_revised.xlsx -o outputs -b demo_python --backend python --compact
echo.
echo Done. Check outputs\demo_python.png and outputs\demo_python.svg
pause
