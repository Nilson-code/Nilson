---
name: crg_stable_dual_backend
description: Generate stable CRG / clock-reset diagrams from Excel. Uses Graphviz if available, otherwise pure Python SVG/PNG rendering.
---

# CRG Stable Dual Backend Skill

This skill converts Excel connectivity tables into stable CRG / clock-reset logic diagrams.

## Input Schema

```text
NAME | TYPE | IN1 | IN2 | IN3 | IN4 | OUT1 | OUT2 | OUT3 | OUT4 | NOTE
```

## Backends

### Auto

```bash
python crg_stable_dual_backend_generator.py -i your.xlsx -o outputs -b result --backend auto --compact
```

- Uses Graphviz if `dot` exists.
- Falls back to pure Python if Graphviz is missing.

### Pure Python

```bash
python crg_stable_dual_backend_generator.py -i your.xlsx -o outputs -b result --backend python --compact
```

No Graphviz required.

## Required Python Packages

```bash
pip install -r requirements.txt
```

Includes:

```text
openpyxl
Pillow
```

## Pure Python Layout Rules

- SRC is fixed at the left.
- SINK is fixed at the right.
- Middle logic uses semantic columns.
- Reset lines are red dashed.
- Enable/control lines are green dotted.
- Clock/data lines are gray solid.
