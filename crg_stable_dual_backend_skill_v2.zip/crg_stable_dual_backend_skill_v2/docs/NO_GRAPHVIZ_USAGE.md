# 无 Graphviz 使用说明

只安装 Python 包：

```bash
pip install -r requirements.txt
```

运行：

```bash
python crg_stable_dual_backend_generator.py -i examples/component_example_logic_revised.xlsx -o outputs -b demo_python --backend python --compact
```

这会生成：

```text
outputs/demo_python.svg
outputs/demo_python.png
outputs/demo_python.dot
outputs/demo_python_report.txt
```
