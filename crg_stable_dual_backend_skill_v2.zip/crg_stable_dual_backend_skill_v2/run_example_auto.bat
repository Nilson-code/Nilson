@echo off
setlocal
echo Running auto backend. Uses Graphviz if available, otherwise pure Python.
python crg_stable_dual_backend_generator.py -i examples\component_example_logic_revised.xlsx -o outputs -b demo_auto --backend auto --compact
echo.
echo Done. Check outputs\demo_auto.png and outputs\demo_auto.svg
pause
